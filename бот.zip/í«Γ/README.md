# Ферма

Backend and local moderation panel for the marketplace. MAX is integrated as the customer-facing interface; payment acceptance remains disabled.

Подробный запуск, заполнение `.env`, подключение MAX и production-чек-лист: [RUNBOOK_RU.md](RUNBOOK_RU.md).

## Что реализовано

- регистрация покупателей и продавцов, роли и подтверждение телефона;
- локации продавца (до 10), покупателя (до 5) и симметричные соседние населённые пункты;
- категории, загрузка JPG/PNG (1–5 фото, до 10 МБ суммарно), черновики, отправка на модерацию, активация на 24 часа, истечение и копирование;
- выдача по локации и категории, сортировка по цене или новизне, избранное и уведомление за час до истечения;
- резервирование с ответом продавца за час и сроком подтверждённого резерва три часа;
- прокси-чат без выдачи номера телефона, жалобы и лента уведомлений;
- локальная панель модератора, аудит, управление ролями/блокировками, рассылка, статистика и CSV-выгрузка;
- OpenAPI-спецификация в `/docs`.

## Быстрый локальный запуск

```text
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn --env-file .env app.main:app --reload
```

Откройте:

- API-документация: `http://127.0.0.1:8000/docs`;
- панель модерации: `http://127.0.0.1:8000/admin`.

Для Docker скопируйте `.env.example` в `.env`, обязательно измените `FERMA_JWT_SECRET`, `FERMA_BOOTSTRAP_SECRET` и задайте настоящий `FERMA_PHONE_ENCRYPTION_KEY`, затем выполните:

```text
docker compose up --build
```

## Первый администратор

1. Зарегистрируйте пользователя через `POST /api/v1/auth/register`. Сохраните `external_id` и токен.
2. Вызовите `POST /api/v1/auth/bootstrap-admin`, передав `external_id`, новый пароль длиной от 12 символов и `bootstrap_secret` из `.env`.
3. Войдите в `/admin` с тем же `external_id` и паролем.

Значение `change-me` допустимо только в локальной разработке. В production оно должно быть заменено до первого запуска.

## Основной жизненный цикл

1. Администратор создаёт географические точки; продавец и покупатель добавляют свои локации.
2. Продавец загружает фото, создаёт черновик и отправляет его на модерацию.
3. После одобрения объявление сразу становится активным на 24 часа, так как платежи отключены.
4. Покупатель из подходящей локации находит товар, открывает чат или создаёт резерв.

При включении СБП `approve_ad` должен переводить объявление в `awaiting_payment`; обработчик проверенного webhook платёжного провайдера активирует его. Это место помечено комментарием в `app/services.py`.

## Будущие интеграции

- **СБП:** сущность `Payment` уже резервирует необходимые поля. Реализуйте `PaymentGateway` в `app/integrations/payments.py`. Webhook обязан проверять подпись провайдера, быть идемпотентным и сопоставлять внешнюю транзакцию с объявлением.
- **SMS:** код подтверждения уже создаётся и хранится хешированным. В development он возвращается в ответе; в production его должен доставлять отдельный SMS-адаптер.
- **S3:** загрузка пока сохраняет файлы в `/uploads`; единственное место замены помечено в `upload_photos`.

## Важные эксплуатационные решения

- Локальное хранилище SQLite — только для разработки; `docker-compose.yml` использует PostgreSQL.
- До подключения воркера истечение сроков обрабатывается при прикладных запросах. В production добавьте периодическую задачу, вызывающую `expire_time_bound_records`.
- Перед публикацией нужны политика обработки персональных данных, согласия, договор с SMS/платёжным провайдером и настройка HTTPS/VPN для `/admin`.
- Миграции БД следует подключить через Alembic до первого production-развёртывания. Изменения очереди MAX добавляют поля в существующие таблицы, поэтому перед обновлением production обязательно примените миграцию; `create_all` создаёт только отсутствующие таблицы. Для локальной SQLite-базы удалите базу или создайте её заново.
## MAX Bot API setup
MAX is the customer-facing interface. The local REST API and `/admin` remain available for development and moderation; set `FERMA_LOCAL_AUTH_ENABLED=false` only after verifying the bot flow.
1. Register a business bot in MAX and copy its API token from the bot settings. Do not put this token in source control.
2. Deploy the application behind a public HTTPS domain on **port 443**. The certificate must be trusted by a CA (self-signed certificates and HTTP are not supported by MAX). Set `FERMA_PUBLIC_BASE_URL` to that domain so product photos can be displayed in MAX.
3. Create a random URL-safe webhook secret (letters, digits, `_` and `-`, 5-256 characters). Put `FERMA_MAX_ENABLED=true`, `FERMA_MAX_BOT_TOKEN`, `FERMA_MAX_WEBHOOK_URL`, and `FERMA_MAX_WEBHOOK_SECRET` in `.env`. The webhook URL must end with `/integrations/max/webhook`.
4. Start the deployment, verify `GET /health` returns `max_enabled: true`, then register the subscription once:
```text
python -m app.max_setup
```
The command registers `bot_started`, `message_created`, and `message_callback` with `https://platform-api2.max.ru/subscriptions`. It does make a live MAX API call, so run it only with final production credentials and endpoint.
The webhook checks `X-Max-Bot-Api-Secret` using constant-time comparison, deduplicates retries, returns HTTP 200 after persisting an event, and handles business logic in a durable database queue. MAX replies and marketplace notifications use a transactional outbox with atomic database claims. Failed inbound and outbound work is retried with exponential backoff (1, 2, 4… seconds by default, capped at 300 seconds); after eight failures it remains visible as failed and is logged at error level. Callback answers receive the same per-dialog 2 requests/responses per second limiter as messages; the enabled worker also applies the 30 requests/second global limiter. Set `FERMA_MAX_WORKER_ENABLED=true` in exactly one process (normally a dedicated worker) and `false` in all API replicas, otherwise the MAX global limit cannot be coordinated between processes. Claims expire after 60 seconds by default so work survives a crashed worker.
For local testing, keep `FERMA_MAX_ENABLED=false`: MAX cannot deliver to `localhost`, plain HTTP, a non-443 port, or a self-signed certificate. Tests use mocked MAX HTTP transport and do not require a token.