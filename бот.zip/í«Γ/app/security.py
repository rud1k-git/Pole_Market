from __future__ import annotations

import base64
import hashlib
import hmac
import os
from datetime import datetime, timedelta, timezone

import jwt
from cryptography.fernet import Fernet
from fastapi import HTTPException, status

from app.config import settings


def encrypt_phone(phone: str) -> str:
    normalized = ''.join(char for char in phone if char.isdigit() or char == '+')
    if settings.phone_encryption_key:
        return Fernet(settings.phone_encryption_key.encode()).encrypt(normalized.encode()).decode()
    if not settings.is_development:
        raise RuntimeError('FERMA_PHONE_ENCRYPTION_KEY must be configured outside development')
    # Development fallback only. Do not deploy reversible base64 as encryption.
    return 'dev:' + base64.urlsafe_b64encode(normalized.encode()).decode()


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    derived = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return base64.urlsafe_b64encode(salt + derived).decode()


def verify_password(password: str, encoded: str) -> bool:
    raw = base64.urlsafe_b64decode(encoded.encode())
    salt, expected = raw[:16], raw[16:]
    actual = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return hmac.compare_digest(actual, expected)


def create_access_token(user_id: int, roles: int, hours: int = 8) -> str:
    expires_at = datetime.now(timezone.utc) + timedelta(hours=hours)
    return jwt.encode({'sub': str(user_id), 'roles': roles, 'exp': expires_at}, settings.jwt_secret, algorithm='HS256')


def decode_access_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=['HS256'])
    except jwt.PyJWTError as error:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid or expired access token') from error


def require_secret(provided: str) -> None:
    if not hmac.compare_digest(provided, settings.bootstrap_secret):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Invalid bootstrap secret')
