from __future__ import annotations
import threading
import time
from collections import defaultdict
from typing import Any, Protocol
import httpx
ButtonRows = list[list[dict[str, Any]]]
class MaxApiError(RuntimeError):
    '''Raised when the MAX API rejects a request or returns an invalid response.'''
class _MaxRateLimiter:
    '''Serializes outbound calls enough to respect MAX global and dialog limits.'''
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._last_global_call = 0.0
        self._last_dialog_call: dict[str, float] = defaultdict(float)
    def wait_turn(self, dialog_id: str | None = None) -> None:
        with self._lock:
            now = time.monotonic()
            delay = max(0.0, (1 / 30) - (now - self._last_global_call))
            if dialog_id:
                delay = max(delay, 0.5 - (now - self._last_dialog_call[dialog_id]))
            if delay:
                time.sleep(delay)
            timestamp = time.monotonic()
            self._last_global_call = timestamp
            if dialog_id:
                self._last_dialog_call[dialog_id] = timestamp
class MessengerGateway(Protocol):
    '''Outbound boundary that keeps MAX transport outside marketplace services.'''
    def deliver(
        self,
        recipient_external_id: str,
        text: str,
        *,
        buttons: ButtonRows | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]: ...
    def acknowledge_callback(
        self,
        callback_id: str,
        recipient_external_id: str,
        text: str | None = None,
    ) -> dict[str, Any]: ...
    def subscribe(self, webhook_url: str, webhook_secret: str, update_types: list[str]) -> dict[str, Any]: ...
class MaxMessenger:
    '''Small synchronous client used only by the durable MAX delivery worker.'''
    def __init__(self, token: str, base_url: str, timeout_seconds: int = 10, transport: httpx.BaseTransport | None = None) -> None:
        if not token:
            raise ValueError('MAX bot token is required')
        self._base_url = base_url.rstrip('/')
        self._timeout = httpx.Timeout(timeout_seconds)
        self._headers = {'Authorization': token}
        self._transport = transport
        self._rate_limiter = _MaxRateLimiter()
    @staticmethod
    def _user_id(recipient_external_id: str) -> str:
        user_id = recipient_external_id.removeprefix('max:')
        if not user_id.isdigit():
            raise ValueError('MAX recipient external_id must contain a numeric user id')
        return user_id
    def _post(self, path: str, *, params: dict[str, Any], body: dict[str, Any], dialog_id: str | None = None) -> dict[str, Any]:
        self._rate_limiter.wait_turn(dialog_id)
        try:
            with httpx.Client(base_url=self._base_url, headers=self._headers, timeout=self._timeout, transport=self._transport) as client:
                response = client.post(path, params=params, json=body)
                response.raise_for_status()
        except httpx.HTTPError as error:
            raise MaxApiError(f'MAX API request to {path} failed: {error}') from error
        try:
            result = response.json()
        except ValueError as error:
            raise MaxApiError(f'MAX API request to {path} returned invalid JSON') from error
        if not isinstance(result, dict):
            raise MaxApiError(f'MAX API request to {path} returned an unexpected response')
        if result.get('success') is False:
            raise MaxApiError(result.get('message') or result.get('code') or f'MAX API request to {path} was rejected')
        return result
    def deliver(
        self,
        recipient_external_id: str,
        text: str,
        *,
        buttons: ButtonRows | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        user_id = self._user_id(recipient_external_id)
        message_attachments = list(attachments or [])
        if buttons:
            message_attachments.append({'type': 'inline_keyboard', 'payload': {'buttons': buttons}})
        body: dict[str, Any] = {'text': text[:4000]}
        if message_attachments:
            body['attachments'] = message_attachments
        return self._post('/messages', params={'user_id': user_id}, body=body, dialog_id=user_id)
    def acknowledge_callback(
        self,
        callback_id: str,
        recipient_external_id: str,
        text: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if text:
            body['notification'] = text[:4000]
        return self._post(
            '/answers',
            params={'callback_id': callback_id},
            body=body,
            dialog_id=self._user_id(recipient_external_id),
        )
    def subscribe(self, webhook_url: str, webhook_secret: str, update_types: list[str]) -> dict[str, Any]:
        return self._post(
            '/subscriptions',
            params={},
            body={'url': webhook_url, 'secret': webhook_secret, 'update_types': update_types},
        )
class DisabledMessenger:
    '''Allows local REST development without an outbound messenger transport.'''
    def deliver(
        self,
        recipient_external_id: str,
        text: str,
        *,
        buttons: ButtonRows | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        return {'success': True, 'disabled': True}
    def acknowledge_callback(
        self,
        callback_id: str,
        recipient_external_id: str,
        text: str | None = None,
    ) -> dict[str, Any]:
        return {'success': True, 'disabled': True}
    def subscribe(self, webhook_url: str, webhook_secret: str, update_types: list[str]) -> dict[str, Any]:
        raise RuntimeError('MAX integration is disabled in this deployment')