'''Pluggable adapters for services intentionally disabled in the local release.'''
