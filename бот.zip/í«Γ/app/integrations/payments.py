from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class PaymentSession:
    reference: str
    qr_code_url: str


class PaymentGateway(Protocol):
    '''Future SBP adapter. Verify provider webhook signatures before activating ads.'''

    def create_session(self, ad_id: int, amount_rub: int) -> PaymentSession: ...


class PaymentsDisabled:
    '''Local release deliberately skips payment collection.'''

    def create_session(self, ad_id: int, amount_rub: int) -> PaymentSession:
        raise RuntimeError('Payments are disabled in this deployment')
