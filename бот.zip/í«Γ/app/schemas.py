from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator, model_validator

from app.models import Availability, Fulfillment, LocationKind


NonEmptyText = Annotated[str, StringConstraints(min_length=1, strip_whitespace=True)]


class RegisterUserInput(BaseModel):
    external_id: str | None = Field(default=None, min_length=3, max_length=128)
    phone: str = Field(min_length=7, max_length=32)
    name: NonEmptyText = Field(max_length=160)
    roles: set[str] = Field(default_factory=lambda: {'buyer'})
    avatar_url: str | None = Field(default=None, max_length=500)
    farm_name: str | None = Field(default=None, max_length=200)

    @field_validator('roles')
    @classmethod
    def validate_roles(cls, value: set[str]) -> set[str]:
        allowed = {'buyer', 'seller'}
        if not value or not value <= allowed:
            raise ValueError('roles may only contain buyer and seller')
        return value


class LocalLoginInput(BaseModel):
    external_id: NonEmptyText = Field(max_length=128)


class BootstrapAdminInput(BaseModel):
    external_id: NonEmptyText = Field(max_length=128)
    password: str = Field(min_length=12, max_length=256)
    bootstrap_secret: NonEmptyText = Field(max_length=512)


class AdminLoginInput(BaseModel):
    external_id: NonEmptyText = Field(max_length=128)
    password: NonEmptyText = Field(max_length=256)


class TokenOutput(BaseModel):
    access_token: str
    token_type: str = 'bearer'
    user_id: int


class LocationInput(BaseModel):
    kind: LocationKind
    name: NonEmptyText = Field(max_length=250)
    latitude: Decimal = Field(ge=-90, le=90)
    longitude: Decimal = Field(ge=-180, le=180)
    parent_id: int | None = Field(default=None, gt=0)


class LocationOutput(LocationInput):
    model_config = ConfigDict(from_attributes=True)
    id: int


class LocationSelectionInput(BaseModel):
    location_id: int = Field(gt=0)


class CategoryInput(BaseModel):
    name: NonEmptyText = Field(max_length=100)
    display_order: int = Field(default=0, ge=0)


class CategoryOutput(CategoryInput):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_active: bool


class AdCreateInput(BaseModel):
    title: NonEmptyText = Field(max_length=200)
    description: str = Field(default='', max_length=1500)
    price: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    unit: NonEmptyText = Field(max_length=30)
    stock_quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    category_id: int = Field(gt=0)
    availability: Availability = Availability.IN_STOCK
    fulfillment: Fulfillment = Fulfillment.PICKUP
    location_ids: list[int] = Field(min_length=1, max_length=10)
    photo_keys: list[str] = Field(min_length=1, max_length=5)

    @field_validator('location_ids')
    @classmethod
    def unique_location_ids(cls, value: list[int]) -> list[int]:
        if len(set(value)) != len(value):
            raise ValueError('location_ids must be unique')
        return value

    @field_validator('photo_keys')
    @classmethod
    def valid_photo_keys(cls, value: list[str]) -> list[str]:
        if len(value) > 5 or any(not key or len(key) > 500 for key in value):
            raise ValueError('one to five valid storage keys are allowed')
        return value


class AdUpdateInput(BaseModel):
    title: NonEmptyText | None = Field(default=None, max_length=200)
    description: str | None = Field(default=None, max_length=1500)
    price: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=2)
    unit: NonEmptyText | None = Field(default=None, max_length=30)
    stock_quantity: Decimal | None = Field(default=None, gt=0, max_digits=12, decimal_places=3)
    category_id: int | None = Field(default=None, gt=0)
    availability: Availability | None = None
    fulfillment: Fulfillment | None = None
    location_ids: list[int] | None = Field(default=None, min_length=1, max_length=10)
    photo_keys: list[str] | None = Field(default=None, max_length=5)


class AdSummaryOutput(BaseModel):
    id: int
    title: str
    price: Decimal
    unit: str
    status: str
    category: str
    seller_name: str
    created_at: datetime
    expires_at: datetime | None


class ReservationCreateInput(BaseModel):
    quantity: Decimal = Field(gt=0, max_digits=12, decimal_places=3)


class ReservationDecisionInput(BaseModel):
    confirm: bool


class ChatMessageInput(BaseModel):
    body: NonEmptyText = Field(max_length=3000)


class ComplaintInput(BaseModel):
    text: NonEmptyText = Field(max_length=1500)


class ModerationDecisionInput(BaseModel):
    approve: bool
    reason: str | None = Field(default=None, max_length=1000)

    @model_validator(mode='after')
    def rejection_reason_required(self):
        if not self.approve and not self.reason:
            raise ValueError('reason is required when an ad is rejected')
        return self


class RoleChangeInput(BaseModel):
    seller_enabled: bool


class BroadcastInput(BaseModel):
    body: NonEmptyText = Field(max_length=3000)


class UserOutput(BaseModel):
    id: int
    external_id: str
    name: str
    farm_name: str | None
    roles: list[str]
    phone_verified: bool
    is_blocked: bool
    created_at: datetime
