'''Backend for the Ferma local-products marketplace.'''
