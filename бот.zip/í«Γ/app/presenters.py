from __future__ import annotations

from sqlalchemy.orm import Session

from app.models import Ad, Location, Role, User
from app.services import reserved_quantity


def role_names(user: User) -> list[str]:
    return [role.name.lower() for role in Role if user.has_role(role)]


def user_data(user: User) -> dict:
    return {
        'id': user.id,
        'external_id': user.external_id,
        'name': user.name,
        'farm_name': user.farm_name,
        'roles': role_names(user),
        'phone_verified': user.phone_verified,
        'is_blocked': user.is_blocked,
        'created_at': user.created_at,
    }


def location_data(location: Location) -> dict:
    return {
        'id': location.id,
        'kind': location.kind.value,
        'name': location.name,
        'latitude': location.latitude,
        'longitude': location.longitude,
        'parent_id': location.parent_id,
    }


def ad_summary(ad: Ad) -> dict:
    return {
        'id': ad.id,
        'title': ad.title,
        'price': ad.price,
        'unit': ad.unit,
        'status': ad.status.value,
        'category': ad.category.name,
        'seller_name': ad.seller.name,
        'created_at': ad.created_at,
        'expires_at': ad.expires_at,
    }


def ad_data(session: Session, ad: Ad) -> dict:
    return {
        **ad_summary(ad),
        'description': ad.description,
        'stock_quantity': ad.stock_quantity,
        'reserved_quantity': reserved_quantity(session, ad.id),
        'available_quantity': None if ad.stock_quantity is None else ad.stock_quantity - reserved_quantity(session, ad.id),
        'availability': ad.availability.value,
        'fulfillment': ad.fulfillment.value,
        'seller': {'id': ad.seller.id, 'name': ad.seller.name, 'farm_name': ad.seller.farm_name},
        'photos': [photo.storage_key for photo in sorted(ad.photos, key=lambda item: item.display_order)],
        'locations': [location_data(item.location) for item in ad.locations],
        'activated_at': ad.activated_at,
        'expires_at': ad.expires_at,
        'rejection_reason': ad.rejection_reason,
    }
