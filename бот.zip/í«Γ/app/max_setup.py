from __future__ import annotations
import re
from urllib.parse import urlparse
from app.config import settings
from app.integrations.messenger import MaxMessenger
UPDATE_TYPES = ['bot_started', 'message_created', 'message_callback']
def validate_setup_settings() -> None:
    if not settings.max_enabled:
        raise RuntimeError('Set FERMA_MAX_ENABLED=true before registering a MAX webhook')
    if not settings.max_bot_token:
        raise RuntimeError('FERMA_MAX_BOT_TOKEN is required')
    if not settings.max_webhook_secret or not re.fullmatch(r'[A-Za-z0-9_-]{5,256}', settings.max_webhook_secret):
        raise RuntimeError('FERMA_MAX_WEBHOOK_SECRET must match [A-Za-z0-9_-]{5,256}')
    if not settings.max_webhook_url:
        raise RuntimeError('FERMA_MAX_WEBHOOK_URL is required')
    parsed = urlparse(settings.max_webhook_url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.port not in {None, 443}:
        raise RuntimeError('FERMA_MAX_WEBHOOK_URL must be an HTTPS URL on port 443')
def main() -> None:
    validate_setup_settings()
    gateway = MaxMessenger(settings.max_bot_token or '', settings.max_api_base_url, settings.max_timeout_seconds)
    result = gateway.subscribe(settings.max_webhook_url or '', settings.max_webhook_secret or '', UPDATE_TYPES)
    print('MAX webhook subscription configured:', result)
if __name__ == '__main__':
    main()