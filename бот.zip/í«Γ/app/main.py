from __future__ import annotations

import asyncio
import csv
from contextlib import asynccontextmanager, suppress
import hashlib
import hmac
import json
import logging
import re
import io
import secrets
import uuid
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from urllib.parse import urlparse

from fastapi import Depends, FastAPI, File, HTTPException, Query, Request, Response, UploadFile, status
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, or_, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.config import settings
from app.database import Base, SessionLocal, engine, get_session
from app.dependencies import ensure_role, get_current_user
from app.models import (
    Ad, AdLocation, AdPhoto, AdStatus, BuyerLocation, Category, ChatMessage, Favorite,
    Complaint, Conversation, Location, LocationNeighbour, ModerationLog, PhoneVerification,
    MaxInboundUpdate, MaxOutboundMessage, NotificationEvent, Reservation, ReservationStatus, Role, SellerLocation, User, utcnow,
)
from app.presenters import ad_data, location_data, user_data
from app.schemas import (
    AdCreateInput, AdUpdateInput, AdminLoginInput, BootstrapAdminInput, BroadcastInput,
    CategoryInput, ChatMessageInput, ComplaintInput, LocalLoginInput, LocationInput,
    LocationSelectionInput, ModerationDecisionInput, RegisterUserInput, ReservationCreateInput,
    ReservationDecisionInput, RoleChangeInput, TokenOutput,
)
from app.security import create_access_token, encrypt_phone, hash_password, require_secret, verify_password
from app.services import (
    approve_ad, assert_seller_locations, create_reservation_expiries, ensure_reservation_capacity,
    expire_time_bound_records, fail, get_user_location_ids, matching_buyer_location_ids, notify,
    reject_ad, require_role, reserved_quantity, set_user_location,
)
from app.integrations.messenger import MaxMessenger
from app.max_bot import MaxBot, queue_pending_notifications

LOGGER = logging.getLogger(__name__)
MAX_UPDATE_TYPES = ['bot_started', 'message_created', 'message_callback']
def validate_max_settings() -> None:
    '''Fail closed: MAX must never expose an unauthenticated webhook route.'''
    if not settings.max_enabled:
        return
    if not settings.max_bot_token:
        raise RuntimeError('FERMA_MAX_BOT_TOKEN is required when FERMA_MAX_ENABLED=true')
    if not settings.max_webhook_secret or not re.fullmatch(r'[A-Za-z0-9_-]{5,256}', settings.max_webhook_secret):
        raise RuntimeError('FERMA_MAX_WEBHOOK_SECRET must match [A-Za-z0-9_-]{5,256}')
    if not settings.max_webhook_url:
        raise RuntimeError('FERMA_MAX_WEBHOOK_URL is required when FERMA_MAX_ENABLED=true')
    parsed_webhook_url = urlparse(settings.max_webhook_url)
    if parsed_webhook_url.scheme != 'https' or not parsed_webhook_url.hostname or parsed_webhook_url.port not in {None, 443}:
        raise RuntimeError('FERMA_MAX_WEBHOOK_URL must be a public HTTPS URL on port 443')
    if settings.max_worker_interval_seconds <= 0 or settings.max_claim_seconds <= 0:
        raise RuntimeError('MAX worker interval and claim duration must be positive')
    if settings.max_retry_max_attempts < 1:
        raise RuntimeError('FERMA_MAX_RETRY_MAX_ATTEMPTS must be at least 1')
    if settings.max_retry_base_seconds <= 0 or settings.max_retry_max_seconds < settings.max_retry_base_seconds:
        raise RuntimeError('MAX retry delays must be positive and ordered')
MAX_INBOUND_BATCH_SIZE = 50
MAX_OUTBOUND_BATCH_SIZE = 100


def _next_max_retry_at(attempts: int):
    delay = min(settings.max_retry_base_seconds * (2 ** max(attempts - 1, 0)), settings.max_retry_max_seconds)
    return utcnow() + timedelta(seconds=delay)


def _claim_max_inbound_updates(limit: int = 1) -> list[tuple[int, str]]:
    now = utcnow()
    claim_expires_at = now + timedelta(seconds=settings.max_claim_seconds)
    with SessionLocal() as session:
        ids = session.scalars(select(MaxInboundUpdate.id).where(
            MaxInboundUpdate.processed_at.is_(None), MaxInboundUpdate.failed_at.is_(None),
            or_(MaxInboundUpdate.next_attempt_at.is_(None), MaxInboundUpdate.next_attempt_at <= now),
            or_(MaxInboundUpdate.claim_expires_at.is_(None), MaxInboundUpdate.claim_expires_at <= now),
        ).order_by(MaxInboundUpdate.id).limit(limit)).all()
        claims: list[tuple[int, str]] = []
        for update_id in ids:
            claim_token = uuid.uuid4().hex
            result = session.execute(update(MaxInboundUpdate).where(
                MaxInboundUpdate.id == update_id, MaxInboundUpdate.processed_at.is_(None),
                MaxInboundUpdate.failed_at.is_(None),
                or_(MaxInboundUpdate.next_attempt_at.is_(None), MaxInboundUpdate.next_attempt_at <= now),
                or_(MaxInboundUpdate.claim_expires_at.is_(None), MaxInboundUpdate.claim_expires_at <= now),
            ).values(claim_token=claim_token, claim_expires_at=claim_expires_at))
            if result.rowcount == 1:
                claims.append((update_id, claim_token))
        session.commit()
    return claims


def _mark_max_inbound_failure(update_id: int, claim_token: str, error: str) -> None:
    now = utcnow()
    with SessionLocal() as session:
        inbound = session.scalar(select(MaxInboundUpdate).where(
            MaxInboundUpdate.id == update_id, MaxInboundUpdate.claim_token == claim_token,
        ))
        if inbound is None:
            return
        inbound.attempts += 1
        inbound.last_error = error[:1000]
        inbound.claim_token = None
        inbound.claim_expires_at = None
        if inbound.attempts >= settings.max_retry_max_attempts:
            inbound.failed_at = now
            inbound.next_attempt_at = None
            LOGGER.error('MAX inbound update id=%s exhausted retry attempts: %s', update_id, inbound.last_error)
        else:
            inbound.next_attempt_at = _next_max_retry_at(inbound.attempts)
        session.commit()


def process_max_inbound_updates() -> list[tuple[str, str]]:
    callback_deliveries: list[tuple[str, str]] = []
    for _ in range(MAX_INBOUND_BATCH_SIZE):
        claims = _claim_max_inbound_updates()
        if not claims:
            break
        update_id, claim_token = claims[0]
        try:
            with SessionLocal() as session:
                inbound = session.scalar(select(MaxInboundUpdate).where(
                    MaxInboundUpdate.id == update_id, MaxInboundUpdate.claim_token == claim_token,
                ))
                if inbound is None:
                    continue
                callback_delivery = MaxBot().process_update(session, inbound)
                inbound.claim_token = None
                inbound.claim_expires_at = None
                queue_pending_notifications(session)
                session.commit()
                if callback_delivery:
                    callback_deliveries.append(callback_delivery)
        except Exception as error:
            LOGGER.exception('Unable to process MAX inbound update id=%s', update_id)
            _mark_max_inbound_failure(update_id, claim_token, str(error))
    return callback_deliveries


def claim_max_messages(limit: int = 1) -> list[tuple[int, str]]:
    now = utcnow()
    claim_expires_at = now + timedelta(seconds=settings.max_claim_seconds)
    with SessionLocal() as session:
        queue_pending_notifications(session)
        ids = session.scalars(select(MaxOutboundMessage.id).join(User).where(
            User.external_id.like('max:%'),
            MaxOutboundMessage.delivered_at.is_(None), MaxOutboundMessage.failed_at.is_(None),
            or_(MaxOutboundMessage.next_attempt_at.is_(None), MaxOutboundMessage.next_attempt_at <= now),
            or_(MaxOutboundMessage.claim_expires_at.is_(None), MaxOutboundMessage.claim_expires_at <= now),
        ).order_by(MaxOutboundMessage.id).limit(limit)).all()
        claims: list[tuple[int, str]] = []
        for message_id in ids:
            claim_token = uuid.uuid4().hex
            result = session.execute(update(MaxOutboundMessage).where(
                MaxOutboundMessage.id == message_id, MaxOutboundMessage.delivered_at.is_(None),
                MaxOutboundMessage.failed_at.is_(None),
                or_(MaxOutboundMessage.next_attempt_at.is_(None), MaxOutboundMessage.next_attempt_at <= now),
                or_(MaxOutboundMessage.claim_expires_at.is_(None), MaxOutboundMessage.claim_expires_at <= now),
            ).values(claim_token=claim_token, claim_expires_at=claim_expires_at))
            if result.rowcount == 1:
                claims.append((message_id, claim_token))
        session.commit()
    return claims


def max_message_data(message_id: int, claim_token: str) -> tuple[str, str, list, list] | None:
    with SessionLocal() as session:
        result = session.execute(select(MaxOutboundMessage, User.external_id).join(User).where(
            MaxOutboundMessage.id == message_id, MaxOutboundMessage.claim_token == claim_token,
            MaxOutboundMessage.delivered_at.is_(None), MaxOutboundMessage.failed_at.is_(None),
        )).one_or_none()
        if result is None:
            return None
        outbound, recipient_external_id = result
        if not recipient_external_id.startswith('max:'):
            return None
        return recipient_external_id, outbound.text, outbound.buttons, outbound.attachments


def mark_max_message_delivered(message_id: int, claim_token: str, delivered: bool, error: str | None = None) -> None:
    now = utcnow()
    with SessionLocal() as session:
        outbound = session.scalar(select(MaxOutboundMessage).where(
            MaxOutboundMessage.id == message_id, MaxOutboundMessage.claim_token == claim_token,
            MaxOutboundMessage.delivered_at.is_(None), MaxOutboundMessage.failed_at.is_(None),
        ))
        if outbound is None:
            return
        outbound.attempts += 1
        outbound.claim_token = None
        outbound.claim_expires_at = None
        if delivered:
            outbound.delivered_at = now
            outbound.next_attempt_at = None
            outbound.last_error = None
            if outbound.notification_event_id:
                event = session.get(NotificationEvent, outbound.notification_event_id)
                if event:
                    event.delivered_at = now
        else:
            outbound.last_error = (error or 'MAX delivery failed')[:1000]
            if outbound.attempts >= settings.max_retry_max_attempts:
                outbound.failed_at = now
                outbound.next_attempt_at = None
                LOGGER.error('MAX outbox message id=%s exhausted retry attempts: %s', message_id, outbound.last_error)
            else:
                outbound.next_attempt_at = _next_max_retry_at(outbound.attempts)
        session.commit()


async def max_worker(gateway: MaxMessenger) -> None:
    while True:
        try:
            callback_deliveries = await asyncio.to_thread(process_max_inbound_updates)
            for callback_id, recipient_external_id in callback_deliveries:
                try:
                    await asyncio.to_thread(gateway.acknowledge_callback, callback_id, recipient_external_id)
                except Exception:
                    LOGGER.exception('Unable to acknowledge MAX callback id=%s', callback_id)
            for _ in range(MAX_OUTBOUND_BATCH_SIZE):
                claims = await asyncio.to_thread(claim_max_messages)
                if not claims:
                    break
                message_id, claim_token = claims[0]
                data = await asyncio.to_thread(max_message_data, message_id, claim_token)
                if data is None:
                    continue
                recipient_external_id, text, buttons, attachments = data
                try:
                    await asyncio.to_thread(gateway.deliver, recipient_external_id, text, buttons=buttons, attachments=attachments)
                except Exception as error:
                    await asyncio.to_thread(mark_max_message_delivered, message_id, claim_token, False, str(error))
                    LOGGER.exception('Unable to deliver MAX message id=%s', message_id)
                else:
                    await asyncio.to_thread(mark_max_message_delivered, message_id, claim_token, True)
        except Exception:
            LOGGER.exception('MAX worker iteration failed')
        await asyncio.sleep(settings.max_worker_interval_seconds)


def initialize_database() -> None:
    Base.metadata.create_all(bind=engine)
    with Session(bind=engine) as session:
        if not session.scalar(select(Category.id).limit(1)):
            session.add_all([Category(name=name, display_order=index) for index, name in enumerate(DEFAULT_CATEGORIES)])
            session.commit()


@asynccontextmanager
async def lifespan(_: FastAPI):
    initialize_database()
    validate_max_settings()
    worker: asyncio.Task | None = None
    if settings.max_enabled and settings.max_worker_enabled:
        gateway = MaxMessenger(settings.max_bot_token or '', settings.max_api_base_url, settings.max_timeout_seconds)
        worker = asyncio.create_task(max_worker(gateway), name='max-outbox-worker')
    try:
        yield
    finally:
        if worker:
            worker.cancel()
            with suppress(asyncio.CancelledError):
                await worker

app = FastAPI(
    title='Ферма API',
    version='0.1.0',
    description='Marketplace backend with MAX bot integration. Payments are disabled.',
    lifespan=lifespan,
)

UPLOAD_DIRECTORY = Path('uploads')
UPLOAD_DIRECTORY.mkdir(exist_ok=True)
app.mount('/uploads', StaticFiles(directory=str(UPLOAD_DIRECTORY)), name='uploads')

DEFAULT_CATEGORIES = ['Овощи', 'Фрукты', 'Ягоды', 'Мясо', 'Птица', 'Молочное', 'Яйца', 'Мёд', 'Хлеб/выпечка', 'Бакалея', 'Напитки', 'Другое']


def require_entity(value, name: str):
    if value is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=name + ' not found')
    return value


def ad_query():
    return select(Ad).options(
        selectinload(Ad.seller), selectinload(Ad.category), selectinload(Ad.photos),
        selectinload(Ad.locations).selectinload(AdLocation.location),
    )


def get_ad(session: Session, ad_id: int) -> Ad:
    return require_entity(session.scalar(ad_query().where(Ad.id == ad_id)), 'Ad')


def commit(session: Session) -> None:
    session.commit()


def audit(session: Session, moderator: User, action: str, target_type: str, target_id: int, details: dict | None = None) -> None:
    session.add(ModerationLog(
        moderator_id=moderator.id, action=action, target_type=target_type, target_id=target_id, details=details or {},
    ))


def verification_hash(code: str) -> str:
    return hashlib.sha256((code + settings.jwt_secret).encode()).hexdigest()


def assert_category(session: Session, category_id: int) -> Category:
    category = session.get(Category, category_id)
    if category is None or not category.is_active:
        fail('Category is not available')
    return category


def assert_locations_exist(session: Session, location_ids: list[int]) -> None:
    found = session.scalar(select(func.count()).select_from(Location).where(Location.id.in_(location_ids))) or 0
    if found != len(set(location_ids)):
        fail('One or more locations do not exist')


def update_ad_fields(session: Session, ad: Ad, payload: AdUpdateInput) -> None:
    data = payload.model_dump(exclude_unset=True)
    location_ids = data.pop('location_ids', None)
    photo_keys = data.pop('photo_keys', None)
    if 'category_id' in data:
        assert_category(session, data['category_id'])
    for field, value in data.items():
        setattr(ad, field, value)
    if location_ids is not None:
        assert_locations_exist(session, location_ids)
        assert_seller_locations(session, ad.seller_id, location_ids)
        ad.locations = [AdLocation(location_id=location_id) for location_id in location_ids]
    if photo_keys is not None:
        ad.photos = [AdPhoto(storage_key=key, display_order=index) for index, key in enumerate(photo_keys)]



@app.get('/health')
def health() -> dict:
    return {
        'status': 'ok',
        'payments_enabled': settings.payments_enabled,
        'local_auth_enabled': settings.local_auth_enabled,
        'max_enabled': settings.max_enabled,
    }
@app.post('/integrations/max/webhook', include_in_schema=False)
async def max_webhook(request: Request) -> dict:
    '''Validate and durably enqueue a MAX update, then acknowledge it before doing business work.'''
    if not settings.max_enabled:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='MAX integration is disabled')
    provided_secret = request.headers.get('X-Max-Bot-Api-Secret', '')
    expected_secret = settings.max_webhook_secret or ''
    if not hmac.compare_digest(provided_secret, expected_secret):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Invalid MAX webhook secret')
    try:
        update = await request.json()
    except json.JSONDecodeError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Invalid JSON update') from error
    if not isinstance(update, dict) or not isinstance(update.get('update_type'), str):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail='Invalid MAX update')
    canonical = json.dumps(update, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    fingerprint = hashlib.sha256(canonical).hexdigest()
    with SessionLocal() as session:
        if session.scalar(select(MaxInboundUpdate.id).where(MaxInboundUpdate.fingerprint == fingerprint)) is None:
            session.add(MaxInboundUpdate(fingerprint=fingerprint, update_type=update['update_type'], payload=update))
            try:
                session.commit()
            except IntegrityError:
                # A concurrent retry won the unique fingerprint race and is already safely queued.
                session.rollback()
    return {'status': 'accepted'}

@app.post('/api/v1/auth/register', response_model=TokenOutput, status_code=status.HTTP_201_CREATED)
def register(payload: RegisterUserInput, session: Session = Depends(get_session)) -> TokenOutput:
    external_id = payload.external_id or 'local-' + uuid.uuid4().hex
    if session.scalar(select(User).where(User.external_id == external_id)):
        fail('external_id is already in use', status.HTTP_409_CONFLICT)
    roles = Role.BUYER if 'buyer' in payload.roles else Role(0)
    if 'seller' in payload.roles:
        roles |= Role.SELLER
    user = User(
        external_id=external_id, phone_ciphertext=encrypt_phone(payload.phone), name=payload.name,
        avatar_url=payload.avatar_url, farm_name=payload.farm_name, roles=int(roles),
        phone_verified=not settings.phone_verification_required,
    )
    session.add(user)
    session.flush()
    commit(session)
    return TokenOutput(access_token=create_access_token(user.id, user.roles), user_id=user.id)


@app.post('/api/v1/auth/local-login', response_model=TokenOutput)
def local_login(payload: LocalLoginInput, session: Session = Depends(get_session)) -> TokenOutput:
    # Disable this route when MAX identity events become the only login source.
    if not settings.local_auth_enabled:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Local authentication is disabled')
    user = require_entity(session.scalar(select(User).where(User.external_id == payload.external_id)), 'User')
    if user.is_blocked:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='User is blocked')
    return TokenOutput(access_token=create_access_token(user.id, user.roles), user_id=user.id)


@app.post('/api/v1/auth/bootstrap-admin', response_model=TokenOutput)
def bootstrap_admin(payload: BootstrapAdminInput, session: Session = Depends(get_session)) -> TokenOutput:
    require_secret(payload.bootstrap_secret)
    user = require_entity(session.scalar(select(User).where(User.external_id == payload.external_id)), 'User')
    user.add_role(Role.ADMIN)
    user.admin_password_hash = hash_password(payload.password)
    audit(session, user, 'bootstrap_admin', 'user', user.id)
    commit(session)
    return TokenOutput(access_token=create_access_token(user.id, user.roles), user_id=user.id)


@app.post('/api/v1/auth/admin-login', response_model=TokenOutput)
def admin_login(payload: AdminLoginInput, session: Session = Depends(get_session)) -> TokenOutput:
    user = require_entity(session.scalar(select(User).where(User.external_id == payload.external_id)), 'User')
    if not user.has_role(Role.ADMIN) or not user.admin_password_hash or not verify_password(payload.password, user.admin_password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid administrator credentials')
    return TokenOutput(access_token=create_access_token(user.id, user.roles), user_id=user.id)


@app.post('/api/v1/auth/phone-verifications')
def begin_phone_verification(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    code = f'{secrets.randbelow(1_000_000):06d}'
    session.add(PhoneVerification(
        user_id=user.id, code_hash=verification_hash(code), expires_at=utcnow() + timedelta(minutes=10),
    ))
    # A future SMS adapter sends the code. The development response is never enabled in production.
    notify(session, user.id, 'phone_verification_requested', {'channel': 'sms'})
    commit(session)
    response = {'message': 'Verification code requested'}
    if settings.is_development:
        response['development_code'] = code
    return response


@app.post('/api/v1/auth/phone-verifications/{code}')
def confirm_phone_verification(code: str, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    verification = session.scalar(select(PhoneVerification).where(
        PhoneVerification.user_id == user.id, PhoneVerification.consumed_at.is_(None),
    ).order_by(PhoneVerification.created_at.desc()))
    if verification is None or verification.expires_at < utcnow() or verification.attempts >= 5:
        fail('Verification code is unavailable or expired', status.HTTP_400_BAD_REQUEST)
    verification.attempts += 1
    if not secrets.compare_digest(verification.code_hash, verification_hash(code)):
        commit(session)
        fail('Invalid verification code', status.HTTP_400_BAD_REQUEST)
    verification.consumed_at = utcnow()
    user.phone_verified = True
    commit(session)
    return {'message': 'Phone verified'}


@app.get('/api/v1/users/me')
def current_profile(user: User = Depends(get_current_user)) -> dict:
    return user_data(user)


@app.get('/api/v1/locations')
def list_locations(query: str | None = Query(default=None, max_length=100), session: Session = Depends(get_session)) -> list[dict]:
    statement = select(Location).order_by(Location.name).limit(100)
    if query:
        statement = statement.where(Location.name.ilike('%' + query + '%'))
    return [location_data(location) for location in session.scalars(statement).all()]


@app.post('/api/v1/admin/locations', status_code=status.HTTP_201_CREATED)
def create_location(payload: LocationInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    if payload.parent_id:
        require_entity(session.get(Location, payload.parent_id), 'Parent location')
    location = Location(**payload.model_dump())
    session.add(location)
    session.flush()
    audit(session, user, 'create_location', 'location', location.id)
    commit(session)
    return location_data(location)


@app.post('/api/v1/admin/locations/{location_id}/neighbours', status_code=status.HTTP_204_NO_CONTENT)
def add_location_neighbour(location_id: int, payload: LocationSelectionInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    ensure_role(user, Role.ADMIN)
    require_entity(session.get(Location, location_id), 'Location')
    require_entity(session.get(Location, payload.location_id), 'Neighbour location')
    for source, target in ((location_id, payload.location_id), (payload.location_id, location_id)):
        if session.get(LocationNeighbour, {'location_id': source, 'neighbour_id': target}) is None:
            session.add(LocationNeighbour(location_id=source, neighbour_id=target))
    audit(session, user, 'link_location_neighbours', 'location', location_id, {'neighbour_id': payload.location_id})
    commit(session)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.put('/api/v1/users/me/locations/{location_id}')
def add_my_location(location_id: int, seller: bool = False, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    role = Role.SELLER if seller else Role.BUYER
    require_role(user, role)
    require_entity(session.get(Location, location_id), 'Location')
    set_user_location(session, user, location_id, as_seller=seller)
    commit(session)
    return {'location_ids': sorted(get_user_location_ids(session, user.id, as_seller=seller))}


@app.delete('/api/v1/users/me/locations/{location_id}', status_code=status.HTTP_204_NO_CONTENT)
def remove_my_location(location_id: int, seller: bool = False, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    role = Role.SELLER if seller else Role.BUYER
    require_role(user, role)
    model = SellerLocation if seller else BuyerLocation
    owner = model.seller_id if seller else model.buyer_id
    link = session.scalar(select(model).where(owner == user.id, model.location_id == location_id))
    if link:
        session.delete(link)
        commit(session)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get('/api/v1/categories')
def list_categories(session: Session = Depends(get_session)) -> list[dict]:
    categories = session.scalars(select(Category).where(Category.is_active.is_(True)).order_by(Category.display_order, Category.name)).all()
    return [{'id': category.id, 'name': category.name, 'display_order': category.display_order, 'is_active': category.is_active} for category in categories]


@app.post('/api/v1/admin/categories', status_code=status.HTTP_201_CREATED)
def create_category(payload: CategoryInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    if session.scalar(select(Category).where(Category.name == payload.name)):
        fail('Category already exists', status.HTTP_409_CONFLICT)
    category = Category(**payload.model_dump())
    session.add(category)
    session.flush()
    audit(session, user, 'create_category', 'category', category.id)
    commit(session)
    return {'id': category.id, 'name': category.name, 'display_order': category.display_order, 'is_active': category.is_active}


@app.post('/api/v1/ads', status_code=status.HTTP_201_CREATED)
def create_ad(payload: AdCreateInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    require_role(user, Role.SELLER)
    if settings.phone_verification_required and not user.phone_verified:
        fail('Seller phone must be verified', status.HTTP_403_FORBIDDEN)
    assert_category(session, payload.category_id)
    assert_locations_exist(session, payload.location_ids)
    assert_seller_locations(session, user.id, payload.location_ids)
    ad = Ad(
        seller_id=user.id, title=payload.title, description=payload.description, price=payload.price, unit=payload.unit,
        stock_quantity=payload.stock_quantity, category_id=payload.category_id, availability=payload.availability,
        fulfillment=payload.fulfillment, status=AdStatus.DRAFT,
    )
    ad.locations = [AdLocation(location_id=location_id) for location_id in payload.location_ids]
    ad.photos = [AdPhoto(storage_key=key, display_order=index) for index, key in enumerate(payload.photo_keys)]
    session.add(ad)
    session.flush()
    commit(session)
    return ad_data(session, get_ad(session, ad.id))


@app.get('/api/v1/ads/mine')
def list_my_ads(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    require_role(user, Role.SELLER)
    expire_time_bound_records(session)
    ads = session.scalars(ad_query().where(Ad.seller_id == user.id).order_by(Ad.created_at.desc())).all()
    commit(session)
    return [ad_data(session, ad) for ad in ads]


@app.patch('/api/v1/ads/{ad_id}')
def edit_ad(ad_id: int, payload: AdUpdateInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ad = get_ad(session, ad_id)
    if ad.seller_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only the seller may edit this ad')
    if ad.status not in {AdStatus.DRAFT, AdStatus.REJECTED}:
        fail('Only draft or rejected ads can be edited')
    update_ad_fields(session, ad, payload)
    if ad.status == AdStatus.REJECTED:
        ad.status = AdStatus.DRAFT
        ad.rejection_reason = None
    commit(session)
    return ad_data(session, get_ad(session, ad.id))



@app.post('/api/v1/ads/{ad_id}/submit')
def submit_ad(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ad = get_ad(session, ad_id)
    if ad.seller_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only the seller may submit this ad')
    if ad.status not in {AdStatus.DRAFT, AdStatus.REJECTED}:
        fail('Only draft or rejected ads can be submitted')
    if settings.phone_verification_required and not user.phone_verified:
        fail('Seller phone must be verified', status.HTTP_403_FORBIDDEN)
    if not ad.photos:
        fail('At least one photo is required before submission')
    ad.status = AdStatus.PENDING_MODERATION
    ad.rejection_reason = None
    notify(session, user.id, 'ad_submitted', {'ad_id': ad.id})
    commit(session)
    return ad_data(session, get_ad(session, ad.id))


@app.delete('/api/v1/ads/{ad_id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_ad(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    ad = get_ad(session, ad_id)
    if ad.seller_id != user.id and not user.has_role(Role.ADMIN):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only seller or administrator may delete this ad')
    ad.status = AdStatus.DELETED
    commit(session)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.post('/api/v1/ads/{ad_id}/copy', status_code=status.HTTP_201_CREATED)
def copy_expired_ad(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    source = get_ad(session, ad_id)
    if source.seller_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only the seller may copy this ad')
    if source.status != AdStatus.EXPIRED:
        fail('Only expired ads can be copied')
    copy = Ad(
        seller_id=source.seller_id, title=source.title, description=source.description, price=source.price,
        unit=source.unit, stock_quantity=source.stock_quantity, category_id=source.category_id,
        availability=source.availability, fulfillment=source.fulfillment, status=AdStatus.DRAFT,
    )
    copy.locations = [AdLocation(location_id=item.location_id) for item in source.locations]
    copy.photos = [AdPhoto(storage_key=item.storage_key, display_order=item.display_order) for item in source.photos]
    session.add(copy)
    session.flush()
    commit(session)
    return ad_data(session, get_ad(session, copy.id))


@app.get('/api/v1/ads')
def browse_ads(
    category_id: int | None = Query(default=None, gt=0),
    sort: str = Query(default='new', pattern='^(new|price_asc|price_desc)$'),
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> list[dict]:
    require_role(user, Role.BUYER)
    expire_time_bound_records(session)
    location_ids = matching_buyer_location_ids(session, user.id)
    if not location_ids:
        commit(session)
        return []
    statement = ad_query().join(AdLocation).where(
        Ad.status == AdStatus.ACTIVE, AdLocation.location_id.in_(location_ids),
    ).distinct()
    if category_id:
        statement = statement.where(Ad.category_id == category_id)
    if sort == 'price_asc':
        statement = statement.order_by(Ad.price.asc(), Ad.id.desc())
    elif sort == 'price_desc':
        statement = statement.order_by(Ad.price.desc(), Ad.id.desc())
    else:
        statement = statement.order_by(Ad.activated_at.desc(), Ad.id.desc())
    ads = session.scalars(statement).all()
    commit(session)
    return [ad_data(session, ad) for ad in ads]


@app.get('/api/v1/ads/{ad_id}')
def view_ad(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    expire_time_bound_records(session)
    ad = get_ad(session, ad_id)
    can_view_nonpublic = user.id == ad.seller_id or user.has_role(Role.ADMIN)
    if ad.status != AdStatus.ACTIVE and not can_view_nonpublic:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Ad not found')
    if ad.status == AdStatus.ACTIVE and not can_view_nonpublic:
        if not ({item.location_id for item in ad.locations} & matching_buyer_location_ids(session, user.id)):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Ad not found for your locations')
    commit(session)
    return ad_data(session, ad)


@app.post('/api/v1/ads/{ad_id}/reservations', status_code=status.HTTP_201_CREATED)
def create_reservation(ad_id: int, payload: ReservationCreateInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    require_role(user, Role.BUYER)
    expire_time_bound_records(session)
    ad = get_ad(session, ad_id)
    if ad.status != AdStatus.ACTIVE:
        fail('Only active ads can be reserved')
    if ad.seller_id == user.id:
        fail('Seller cannot reserve their own ad')
    if not ({item.location_id for item in ad.locations} & matching_buyer_location_ids(session, user.id)):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Ad not found for your locations')
    ensure_reservation_capacity(session, ad, payload.quantity)
    response_deadline, _ = create_reservation_expiries()
    reservation = Reservation(
        ad_id=ad.id, buyer_id=user.id, quantity=payload.quantity,
        status=ReservationStatus.PENDING, response_deadline_at=response_deadline,
    )
    session.add(reservation)
    session.flush()
    notify(session, ad.seller_id, 'reservation_requested', {
        'reservation_id': reservation.id, 'ad_id': ad.id, 'buyer_name': user.name, 'quantity': str(payload.quantity),
    })
    commit(session)
    return {'id': reservation.id, 'status': reservation.status.value, 'response_deadline_at': reservation.response_deadline_at}


@app.get('/api/v1/reservations/incoming')
def incoming_reservations(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    require_role(user, Role.SELLER)
    expire_time_bound_records(session)
    reservations = session.scalars(
        select(Reservation).join(Ad).where(Ad.seller_id == user.id).order_by(Reservation.created_at.desc())
    ).all()
    commit(session)
    return [{
        'id': item.id, 'ad_id': item.ad_id, 'ad_title': item.ad.title, 'buyer': {'id': item.buyer.id, 'name': item.buyer.name},
        'quantity': item.quantity, 'status': item.status.value, 'response_deadline_at': item.response_deadline_at, 'expires_at': item.expires_at,
    } for item in reservations]


@app.post('/api/v1/reservations/{reservation_id}/decision')
def decide_reservation(reservation_id: int, payload: ReservationDecisionInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    require_role(user, Role.SELLER)
    expire_time_bound_records(session)
    reservation = require_entity(session.get(Reservation, reservation_id), 'Reservation')
    if reservation.ad.seller_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only the seller may decide this reservation')
    if reservation.status != ReservationStatus.PENDING:
        fail('Reservation is no longer awaiting a decision')
    now = utcnow()
    reservation.responded_at = now
    if payload.confirm:
        reservation.status = ReservationStatus.CONFIRMED
        reservation.expires_at = now + timedelta(hours=settings.reservation_lifetime_hours)
        event = 'reservation_confirmed'
    else:
        reservation.status = ReservationStatus.DECLINED
        event = 'reservation_declined'
    notify(session, reservation.buyer_id, event, {'reservation_id': reservation.id, 'ad_id': reservation.ad_id})
    commit(session)
    return {'id': reservation.id, 'status': reservation.status.value, 'expires_at': reservation.expires_at}


@app.post('/api/v1/reservations/{reservation_id}/cancel')
def cancel_reservation(reservation_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    reservation = require_entity(session.get(Reservation, reservation_id), 'Reservation')
    if reservation.buyer_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Only the buyer may cancel this reservation')
    if reservation.status not in {ReservationStatus.PENDING, ReservationStatus.CONFIRMED}:
        fail('Reservation cannot be cancelled')
    reservation.status = ReservationStatus.CANCELLED
    reservation.responded_at = utcnow()
    notify(session, reservation.ad.seller_id, 'reservation_cancelled', {'reservation_id': reservation.id})
    commit(session)
    return {'id': reservation.id, 'status': reservation.status.value}


def get_conversation_for_user(session: Session, conversation_id: int, user_id: int) -> Conversation:
    conversation = require_entity(session.get(Conversation, conversation_id), 'Conversation')
    if user_id not in {conversation.buyer_id, conversation.seller_id}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Conversation is not available')
    return conversation


@app.post('/api/v1/ads/{ad_id}/conversation', status_code=status.HTTP_201_CREATED)
def open_conversation(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    require_role(user, Role.BUYER)
    ad = get_ad(session, ad_id)
    if ad.status != AdStatus.ACTIVE:
        fail('Conversation can only be opened for an active ad')
    if ad.seller_id == user.id:
        fail('Seller cannot open a conversation with themselves')
    if not ({item.location_id for item in ad.locations} & matching_buyer_location_ids(session, user.id)):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Ad not found for your locations')
    conversation = session.scalar(select(Conversation).where(
        Conversation.ad_id == ad.id, Conversation.buyer_id == user.id, Conversation.seller_id == ad.seller_id,
    ))
    if conversation is None:
        conversation = Conversation(ad_id=ad.id, buyer_id=user.id, seller_id=ad.seller_id)
        session.add(conversation)
        session.flush()
        commit(session)
    return {'id': conversation.id, 'ad_id': conversation.ad_id, 'buyer_id': conversation.buyer_id, 'seller_id': conversation.seller_id}


@app.get('/api/v1/conversations')
def list_conversations(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    conversations = session.scalars(select(Conversation).where(
        (Conversation.buyer_id == user.id) | (Conversation.seller_id == user.id),
    ).order_by(Conversation.created_at.desc())).all()
    return [{'id': item.id, 'ad_id': item.ad_id, 'buyer_id': item.buyer_id, 'seller_id': item.seller_id, 'created_at': item.created_at} for item in conversations]


@app.get('/api/v1/conversations/{conversation_id}/messages')
def list_messages(conversation_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    get_conversation_for_user(session, conversation_id, user.id)
    messages = session.scalars(select(ChatMessage).where(ChatMessage.conversation_id == conversation_id).order_by(ChatMessage.created_at)).all()
    return [{'id': item.id, 'sender_id': item.sender_id, 'body': item.body, 'created_at': item.created_at} for item in messages]


@app.post('/api/v1/conversations/{conversation_id}/messages', status_code=status.HTTP_201_CREATED)
def send_message(conversation_id: int, payload: ChatMessageInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    conversation = get_conversation_for_user(session, conversation_id, user.id)
    if conversation.closed_at:
        fail('Conversation is closed')
    message = ChatMessage(conversation_id=conversation.id, sender_id=user.id, body=payload.body)
    session.add(message)
    recipient_id = conversation.seller_id if user.id == conversation.buyer_id else conversation.buyer_id
    notify(session, recipient_id, 'chat_message', {'conversation_id': conversation.id, 'sender_id': user.id})
    session.flush()
    commit(session)
    return {'id': message.id, 'sender_id': message.sender_id, 'body': message.body, 'created_at': message.created_at}


@app.post('/api/v1/ads/{ad_id}/complaints', status_code=status.HTTP_201_CREATED)
def create_complaint(ad_id: int, payload: ComplaintInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    get_ad(session, ad_id)
    complaint = Complaint(ad_id=ad_id, reporter_id=user.id, text=payload.text)
    session.add(complaint)
    session.flush()
    commit(session)
    return {'id': complaint.id, 'message': 'Complaint accepted'}


@app.get('/api/v1/admin/moderation/ads')
def moderation_queue(
    category_id: int | None = Query(default=None, gt=0),
    seller_id: int | None = Query(default=None, gt=0),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    user: User = Depends(get_current_user),
    session: Session = Depends(get_session),
) -> dict:
    ensure_role(user, Role.ADMIN)
    statement = ad_query().where(Ad.status == AdStatus.PENDING_MODERATION).order_by(Ad.created_at).offset(offset).limit(limit)
    if category_id:
        statement = statement.where(Ad.category_id == category_id)
    if seller_id:
        statement = statement.where(Ad.seller_id == seller_id)
    ads = session.scalars(statement).all()
    return {'items': [ad_data(session, ad) for ad in ads], 'offset': offset, 'limit': limit}


@app.post('/api/v1/admin/moderation/ads/{ad_id}')
def moderate_ad(ad_id: int, payload: ModerationDecisionInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    ad = get_ad(session, ad_id)
    if payload.approve:
        approve_ad(session, ad, user)
        audit(session, user, 'approve_ad', 'ad', ad.id)
    else:
        reject_ad(session, ad, user, payload.reason or '')
        audit(session, user, 'reject_ad', 'ad', ad.id, {'reason': payload.reason})
    commit(session)
    return ad_data(session, get_ad(session, ad.id))


@app.patch('/api/v1/admin/users/{target_user_id}/seller-role')
def set_seller_role(target_user_id: int, payload: RoleChangeInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    target = require_entity(session.get(User, target_user_id), 'User')
    if payload.seller_enabled:
        target.add_role(Role.SELLER)
        action = 'grant_seller_role'
    else:
        target.remove_role(Role.SELLER)
        for ad in session.scalars(select(Ad).where(Ad.seller_id == target.id, Ad.status != AdStatus.DELETED)).all():
            ad.status = AdStatus.DELETED
        action = 'revoke_seller_role'
    audit(session, user, action, 'user', target.id)
    commit(session)
    return user_data(target)


@app.post('/api/v1/admin/users/{target_user_id}/block')
def set_user_block(
    target_user_id: int, blocked: bool = True, user: User = Depends(get_current_user), session: Session = Depends(get_session),
) -> dict:
    ensure_role(user, Role.ADMIN)
    target = require_entity(session.get(User, target_user_id), 'User')
    if target.id == user.id and blocked:
        fail('Administrator cannot block themselves')
    target.is_blocked = blocked
    if blocked:
        for ad in session.scalars(select(Ad).where(Ad.seller_id == target.id, Ad.status == AdStatus.ACTIVE)).all():
            ad.status = AdStatus.DELETED
    audit(session, user, 'block_user' if blocked else 'unblock_user', 'user', target.id)
    commit(session)
    return user_data(target)


@app.get('/api/v1/admin/complaints')
def list_complaints(
    unresolved_only: bool = True, user: User = Depends(get_current_user), session: Session = Depends(get_session),
) -> list[dict]:
    ensure_role(user, Role.ADMIN)
    statement = select(Complaint).order_by(Complaint.created_at.desc())
    if unresolved_only:
        statement = statement.where(Complaint.resolved_at.is_(None))
    complaints = session.scalars(statement).all()
    return [{
        'id': item.id, 'ad_id': item.ad_id, 'reporter_id': item.reporter_id, 'text': item.text,
        'created_at': item.created_at, 'resolved_at': item.resolved_at,
    } for item in complaints]


@app.post('/api/v1/admin/complaints/{complaint_id}/resolve')
def resolve_complaint(complaint_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    complaint = require_entity(session.get(Complaint, complaint_id), 'Complaint')
    complaint.resolved_at = utcnow()
    audit(session, user, 'resolve_complaint', 'complaint', complaint.id)
    commit(session)
    return {'id': complaint.id, 'resolved_at': complaint.resolved_at}


@app.post('/api/v1/admin/broadcast')
def broadcast(payload: BroadcastInput, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    recipient_ids = session.scalars(select(User.id).where(User.is_blocked.is_(False))).all()
    for recipient_id in recipient_ids:
        notify(session, recipient_id, 'broadcast', {'body': payload.body})
    audit(session, user, 'broadcast', 'users', 0, {'recipient_count': len(recipient_ids)})
    commit(session)
    return {'recipient_count': len(recipient_ids)}


@app.get('/api/v1/admin/statistics')
def statistics(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> dict:
    ensure_role(user, Role.ADMIN)
    expire_time_bound_records(session)
    total_users = session.scalar(select(func.count()).select_from(User)) or 0
    seller_count = session.scalar(select(func.count()).select_from(User).where(User.roles.op('&')(int(Role.SELLER)) != 0)) or 0
    buyer_count = session.scalar(select(func.count()).select_from(User).where(User.roles.op('&')(int(Role.BUYER)) != 0)) or 0
    active_ads = session.scalar(select(func.count()).select_from(Ad).where(Ad.status == AdStatus.ACTIVE)) or 0
    pending_ads = session.scalar(select(func.count()).select_from(Ad).where(Ad.status == AdStatus.PENDING_MODERATION)) or 0
    commit(session)
    return {
        'users': {'total': total_users, 'buyers': buyer_count, 'sellers': seller_count},
        'ads': {'active': active_ads, 'pending_moderation': pending_ads},
        'payments': {'enabled': settings.payments_enabled, 'amount': Decimal('0.00')},
    }


@app.get('/api/v1/admin/reports/ads.csv')
def export_ads_report(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    ensure_role(user, Role.ADMIN)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['id', 'status', 'title', 'category', 'seller_id', 'price', 'unit', 'created_at', 'expires_at'])
    ads = session.scalars(ad_query().order_by(Ad.id)).all()
    for ad in ads:
        writer.writerow([ad.id, ad.status.value, ad.title, ad.category.name, ad.seller_id, ad.price, ad.unit, ad.created_at.isoformat(), ad.expires_at.isoformat() if ad.expires_at else ''])
    return Response(content=output.getvalue(), media_type='text/csv; charset=utf-8', headers={'Content-Disposition': 'attachment; filename=ads-report.csv'})


@app.get('/api/v1/notifications')
def list_notifications(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    from app.models import NotificationEvent
    events = session.scalars(select(NotificationEvent).where(NotificationEvent.recipient_id == user.id).order_by(NotificationEvent.created_at.desc()).limit(100)).all()
    return [{'id': event.id, 'type': event.event_type, 'payload': event.payload, 'created_at': event.created_at} for event in events]


@app.get('/admin', response_class=HTMLResponse, include_in_schema=False)
def admin_site() -> str:
    '''Small dependency-free moderation UI; deploy it only behind HTTPS/VPN in production.'''
    return """<!doctype html>
<html lang='ru'>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <title>Ферма — модерация</title>
  <style>
    :root { color-scheme: light; font-family: system-ui, sans-serif; background: #f6f8f5; color: #202820; }
    body { max-width: 1040px; margin: 0 auto; padding: 24px; }
    header, section, article { background: #fff; border: 1px solid #dce3d8; border-radius: 10px; padding: 18px; margin-bottom: 16px; }
    h1, h2, p { margin-top: 0; }
    .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    input { padding: 9px; border: 1px solid #aab7a6; border-radius: 6px; min-width: 180px; }
    button { padding: 9px 12px; background: #2d6a3f; color: #fff; border: 0; border-radius: 6px; cursor: pointer; }
    button.secondary { background: #606b60; }
    button.reject { background: #9e3434; }
    #status { min-height: 20px; color: #9e3434; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
    .metric { background: #edf4ea; padding: 12px; border-radius: 6px; }
    article p { margin-bottom: 8px; }
  </style>
</head>
<body>
  <header>
    <h1>Ферма — модерация</h1>
    <p>Локальная панель. Для рабочего сервера ограничьте доступ VPN и включите HTTPS.</p>
    <div class='row'>
      <input id='externalId' placeholder='Локальный ID администратора'>
      <input id='password' type='password' placeholder='Пароль администратора'>
      <button id='login'>Войти</button>
      <button class='secondary' id='logout'>Выйти</button>
    </div>
    <p id='status'></p>
  </header>
  <section>
    <div class='row'><h2>Статистика</h2><button id='refresh' class='secondary'>Обновить</button></div>
    <div id='stats' class='grid'></div>
  </section>
  <section>
    <h2>Очередь модерации</h2>
    <div id='queue'></div>
  </section>
  <script>
    const tokenKey = 'ferma-admin-token';
    const statusNode = document.querySelector('#status');
    const escapeHtml = value => String(value).replace(/[&<>\"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[char]));
    async function request(url, options = {}) {
      const token = localStorage.getItem(tokenKey);
      const headers = Object.assign({'Content-Type': 'application/json'}, options.headers || {});
      if (token) headers.Authorization = 'Bearer ' + token;
      const response = await fetch(url, Object.assign({}, options, {headers}));
      if (!response.ok) { const body = await response.json().catch(() => ({})); throw new Error(body.detail || 'Ошибка запроса'); }
      return response.status === 204 ? null : response.json();
    }
    async function refresh() {
      try {
        const [stats, queue] = await Promise.all([request('/api/v1/admin/statistics'), request('/api/v1/admin/moderation/ads')]);
        document.querySelector('#stats').innerHTML = [
          ['Пользователей', stats.users.total], ['Покупателей', stats.users.buyers],
          ['Продавцов', stats.users.sellers], ['Активных объявлений', stats.ads.active],
          ['На модерации', stats.ads.pending_moderation],
        ].map(([label, value]) => `<div class='metric'><strong>${value}</strong><br>${label}</div>`).join('');
        document.querySelector('#queue').innerHTML = queue.items.length ? queue.items.map(ad => `
          <article>
            <h3>${escapeHtml(ad.title)} <small>№${ad.id}</small></h3>
            <p>${escapeHtml(ad.description || 'Без описания')}</p>
            <p><strong>${ad.price} ₽/${escapeHtml(ad.unit)}</strong> · ${escapeHtml(ad.category)} · ${escapeHtml(ad.seller.name)}</p>
            <div class='row'><button onclick='moderate(${ad.id}, true)'>Одобрить</button><button class='reject' onclick='moderate(${ad.id}, false)'>Отклонить</button></div>
          </article>`).join('') : '<p>В очереди нет объявлений.</p>';
        statusNode.textContent = '';
      } catch (error) { statusNode.textContent = error.message; }
    }
    window.moderate = async (id, approve) => {
      const reason = approve ? null : prompt('Укажите причину отклонения');
      if (!approve && !reason) return;
      try { await request('/api/v1/admin/moderation/ads/' + id, {method: 'POST', body: JSON.stringify({approve, reason})}); await refresh(); } catch (error) { statusNode.textContent = error.message; }
    };
    document.querySelector('#login').addEventListener('click', async () => {
      try {
        const result = await request('/api/v1/auth/admin-login', {method: 'POST', headers: {}, body: JSON.stringify({external_id: document.querySelector('#externalId').value, password: document.querySelector('#password').value})});
        localStorage.setItem(tokenKey, result.access_token);
        await refresh();
      } catch (error) { statusNode.textContent = error.message; }
    });
    document.querySelector('#logout').addEventListener('click', () => { localStorage.removeItem(tokenKey); document.querySelector('#stats').innerHTML = ''; document.querySelector('#queue').innerHTML = ''; });
    document.querySelector('#refresh').addEventListener('click', refresh);
    if (localStorage.getItem(tokenKey)) refresh();
  </script>
</body>
</html>"""


@app.post('/api/v1/uploads/photos', status_code=status.HTTP_201_CREATED)
async def upload_photos(
    files: list[UploadFile] = File(...),
    user: User = Depends(get_current_user),
) -> dict:
    require_role(user, Role.SELLER)
    if not 1 <= len(files) <= 5:
        fail('Upload from one to five photos at once')
    allowed_types = {'image/jpeg': '.jpg', 'image/png': '.png'}
    prepared: list[tuple[str, bytes]] = []
    total_size = 0
    for file in files:
        if file.content_type not in allowed_types:
            fail('Only JPG and PNG photos are allowed')
        content = await file.read()
        total_size += len(content)
        if total_size > 10 * 1024 * 1024:
            fail('Total photo size must not exceed 10 MB')
        prepared.append((allowed_types[file.content_type], content))
    keys: list[str] = []
    for extension, content in prepared:
        # Replace this local write with an S3 storage adapter without changing ad endpoints.
        filename = uuid.uuid4().hex + extension
        (UPLOAD_DIRECTORY / filename).write_bytes(content)
        keys.append('/uploads/' + filename)
    return {'photo_keys': keys}


@app.put('/api/v1/ads/{ad_id}/favorite', status_code=status.HTTP_204_NO_CONTENT)
def add_favorite(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    require_role(user, Role.BUYER)
    ad = get_ad(session, ad_id)
    if ad.status != AdStatus.ACTIVE or not ({item.location_id for item in ad.locations} & matching_buyer_location_ids(session, user.id)):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Ad not found for your locations')
    if session.get(Favorite, {'buyer_id': user.id, 'ad_id': ad.id}) is None:
        session.add(Favorite(buyer_id=user.id, ad_id=ad.id))
        commit(session)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.delete('/api/v1/ads/{ad_id}/favorite', status_code=status.HTTP_204_NO_CONTENT)
def remove_favorite(ad_id: int, user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Response:
    favorite = session.get(Favorite, {'buyer_id': user.id, 'ad_id': ad_id})
    if favorite:
        session.delete(favorite)
        commit(session)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get('/api/v1/favorites')
def list_favorites(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> list[dict]:
    require_role(user, Role.BUYER)
    expire_time_bound_records(session)
    ads = session.scalars(
        ad_query().join(Favorite).where(Favorite.buyer_id == user.id, Ad.status == AdStatus.ACTIVE).order_by(Favorite.created_at.desc())
    ).all()
    commit(session)
    return [ad_data(session, ad) for ad in ads]
