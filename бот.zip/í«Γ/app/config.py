from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
def _load_dotenv() -> None:
    '''Load the local deployment file without overwriting real process environment variables.'''
    env_file = Path('.env')
    if not env_file.is_file():
        return
    for raw_line in env_file.read_text(encoding='utf-8').splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        key, value = line.split('=', 1)
        key = key.strip()
        if not key or not key.replace('_', '').isalnum():
            continue
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)
_load_dotenv()
def _as_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}
@dataclass(frozen=True)
class Settings:
    environment: str
    database_url: str
    jwt_secret: str
    phone_encryption_key: str | None
    bootstrap_secret: str
    local_auth_enabled: bool
    payments_enabled: bool
    max_enabled: bool
    max_bot_token: str | None
    max_webhook_url: str | None
    max_webhook_secret: str | None
    max_api_base_url: str
    max_timeout_seconds: int
    max_worker_interval_seconds: float
    max_worker_enabled: bool
    max_retry_max_attempts: int
    max_retry_base_seconds: float
    max_retry_max_seconds: float
    max_claim_seconds: float
    public_base_url: str | None
    phone_verification_required: bool
    ad_lifetime_hours: int
    reservation_response_minutes: int
    reservation_lifetime_hours: int
    @property
    def is_development(self) -> bool:
        return self.environment == 'development'
def load_settings() -> Settings:
    return Settings(
        environment=os.getenv('FERMA_ENVIRONMENT', 'development'),
        database_url=os.getenv('FERMA_DATABASE_URL', 'sqlite:///./ferma.db'),
        jwt_secret=os.getenv('FERMA_JWT_SECRET', 'development-secret-change-before-deploy'),
        phone_encryption_key=os.getenv('FERMA_PHONE_ENCRYPTION_KEY') or None,
        bootstrap_secret=os.getenv('FERMA_BOOTSTRAP_SECRET', 'change-me'),
        local_auth_enabled=_as_bool(os.getenv('FERMA_LOCAL_AUTH_ENABLED'), True),
        payments_enabled=_as_bool(os.getenv('FERMA_PAYMENTS_ENABLED'), False),
        max_enabled=_as_bool(os.getenv('FERMA_MAX_ENABLED'), False),
        max_bot_token=os.getenv('FERMA_MAX_BOT_TOKEN') or None,
        max_webhook_url=os.getenv('FERMA_MAX_WEBHOOK_URL') or None,
        max_webhook_secret=os.getenv('FERMA_MAX_WEBHOOK_SECRET') or None,
        max_api_base_url=os.getenv('FERMA_MAX_API_BASE_URL', 'https://platform-api2.max.ru').rstrip('/'),
        max_timeout_seconds=int(os.getenv('FERMA_MAX_TIMEOUT_SECONDS', '10')),
        max_worker_interval_seconds=float(os.getenv('FERMA_MAX_WORKER_INTERVAL_SECONDS', '1')),
        max_worker_enabled=_as_bool(os.getenv('FERMA_MAX_WORKER_ENABLED'), True),
        max_retry_max_attempts=int(os.getenv('FERMA_MAX_RETRY_MAX_ATTEMPTS', '8')),
        max_retry_base_seconds=float(os.getenv('FERMA_MAX_RETRY_BASE_SECONDS', '1')),
        max_retry_max_seconds=float(os.getenv('FERMA_MAX_RETRY_MAX_SECONDS', '300')),
        max_claim_seconds=float(os.getenv('FERMA_MAX_CLAIM_SECONDS', '60')),
        public_base_url=(os.getenv('FERMA_PUBLIC_BASE_URL') or '').rstrip('/') or None,
        phone_verification_required=_as_bool(os.getenv('FERMA_PHONE_VERIFICATION_REQUIRED'), True),
        ad_lifetime_hours=int(os.getenv('FERMA_AD_LIFETIME_HOURS', '24')),
        reservation_response_minutes=int(os.getenv('FERMA_RESERVATION_RESPONSE_MINUTES', '60')),
        reservation_lifetime_hours=int(os.getenv('FERMA_RESERVATION_LIFETIME_HOURS', '3')),
    )
settings = load_settings()