from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import (
    Ad, AdStatus, BuyerLocation, Favorite, LocationNeighbour, NotificationEvent, Reservation,
    ReservationStatus, Role, SellerLocation, User, utcnow,
)


def fail(detail: str, code: int = status.HTTP_400_BAD_REQUEST) -> None:
    raise HTTPException(status_code=code, detail=detail)


def require_role(user: User, role: Role) -> None:
    if not user.has_role(role):
        fail('This action requires the ' + role.name.lower() + ' role', status.HTTP_403_FORBIDDEN)
    if user.is_blocked:
        fail('User is blocked', status.HTTP_403_FORBIDDEN)


def notify(session: Session, recipient_id: int, event_type: str, payload: dict) -> None:
    '''Events are persisted now; a MAX worker can deliver them later without losing events.'''
    session.add(NotificationEvent(recipient_id=recipient_id, event_type=event_type, payload=payload))


def expire_time_bound_records(session: Session) -> None:
    now = utcnow()
    warning_cutoff = now + timedelta(hours=1)
    expiring_ads = session.scalars(
        select(Ad).where(
            Ad.status == AdStatus.ACTIVE,
            Ad.expires_at.is_not(None),
            Ad.expires_at > now,
            Ad.expires_at <= warning_cutoff,
            Ad.expiry_warning_sent.is_(False),
        )
    ).all()
    for ad in expiring_ads:
        ad.expiry_warning_sent = True
        payload = {'ad_id': ad.id, 'expires_at': ad.expires_at.isoformat()}
        notify(session, ad.seller_id, 'ad_expiring_soon', payload)
        for buyer_id in session.scalars(select(Favorite.buyer_id).where(Favorite.ad_id == ad.id)).all():
            notify(session, buyer_id, 'favorite_ad_expiring_soon', payload)

    active_ads = session.scalars(
        select(Ad).where(Ad.status == AdStatus.ACTIVE, Ad.expires_at.is_not(None), Ad.expires_at <= now)
    ).all()
    for ad in active_ads:
        ad.status = AdStatus.EXPIRED
        notify(session, ad.seller_id, 'ad_expired', {'ad_id': ad.id})

    waiting_reservations = session.scalars(
        select(Reservation).where(
            Reservation.status == ReservationStatus.PENDING,
            Reservation.response_deadline_at <= now,
        )
    ).all()
    for reservation in waiting_reservations:
        reservation.status = ReservationStatus.EXPIRED
        reservation.responded_at = now
        notify(session, reservation.buyer_id, 'reservation_expired', {'reservation_id': reservation.id})

    confirmed_reservations = session.scalars(
        select(Reservation).where(
            Reservation.status == ReservationStatus.CONFIRMED,
            Reservation.expires_at.is_not(None),
            Reservation.expires_at <= now,
        )
    ).all()
    for reservation in confirmed_reservations:
        reservation.status = ReservationStatus.EXPIRED
        notify(session, reservation.buyer_id, 'reservation_expired', {'reservation_id': reservation.id})


def set_user_location(session: Session, user: User, location_id: int, as_seller: bool) -> None:
    model = SellerLocation if as_seller else BuyerLocation
    owner_field = model.seller_id if as_seller else model.buyer_id
    limit = 10 if as_seller else 5
    existing = session.scalar(select(model).where(owner_field == user.id, model.location_id == location_id))
    if existing:
        return
    count = session.scalar(select(func.count()).select_from(model).where(owner_field == user.id)) or 0
    if count >= limit:
        fail('Seller may have at most 10 locations' if as_seller else 'Buyer may have at most 5 locations')
    session.add(model(**({'seller_id': user.id} if as_seller else {'buyer_id': user.id}), location_id=location_id))


def get_user_location_ids(session: Session, user_id: int, as_seller: bool) -> set[int]:
    model = SellerLocation if as_seller else BuyerLocation
    owner_field = model.seller_id if as_seller else model.buyer_id
    return set(session.scalars(select(model.location_id).where(owner_field == user_id)).all())


def matching_buyer_location_ids(session: Session, buyer_id: int) -> set[int]:
    preferred_ids = get_user_location_ids(session, buyer_id, as_seller=False)
    if not preferred_ids:
        return set()
    neighbour_ids = set(session.scalars(
        select(LocationNeighbour.neighbour_id).where(LocationNeighbour.location_id.in_(preferred_ids))
    ).all())
    return preferred_ids | neighbour_ids


def assert_seller_locations(session: Session, seller_id: int, location_ids: list[int]) -> None:
    allowed = get_user_location_ids(session, seller_id, as_seller=True)
    if not set(location_ids) <= allowed:
        fail('Each ad location must belong to the seller')


def reserved_quantity(session: Session, ad_id: int) -> Decimal:
    total = session.scalar(
        select(func.coalesce(func.sum(Reservation.quantity), 0)).where(
            Reservation.ad_id == ad_id,
            Reservation.status.in_([ReservationStatus.PENDING, ReservationStatus.CONFIRMED]),
        )
    )
    return Decimal(str(total))


def ensure_reservation_capacity(session: Session, ad: Ad, requested: Decimal) -> None:
    if ad.stock_quantity is None:
        return
    if reserved_quantity(session, ad.id) + requested > ad.stock_quantity:
        fail('Requested quantity exceeds available stock')


def approve_ad(session: Session, ad: Ad, moderator: User) -> None:
    if ad.status != AdStatus.PENDING_MODERATION:
        fail('Only ads awaiting moderation can be approved')
    active_count = session.scalar(
        select(func.count()).select_from(Ad).where(Ad.seller_id == ad.seller_id, Ad.status == AdStatus.ACTIVE)
    ) or 0
    if active_count >= 100:
        fail('Seller already has 100 active ads')
    now = utcnow()
    ad.moderated_by_id = moderator.id
    ad.rejection_reason = None
    # When SBP is enabled, replace this branch with AWAITING_PAYMENT and create a payment session.
    ad.status = AdStatus.ACTIVE
    ad.activated_at = now
    ad.expires_at = now + timedelta(hours=settings.ad_lifetime_hours)
    ad.expiry_warning_sent = False
    notify(session, ad.seller_id, 'ad_approved', {'ad_id': ad.id, 'expires_at': ad.expires_at.isoformat()})


def reject_ad(session: Session, ad: Ad, moderator: User, reason: str) -> None:
    if ad.status != AdStatus.PENDING_MODERATION:
        fail('Only ads awaiting moderation can be rejected')
    ad.status = AdStatus.REJECTED
    ad.moderated_by_id = moderator.id
    ad.rejection_reason = reason
    notify(session, ad.seller_id, 'ad_rejected', {'ad_id': ad.id, 'reason': reason})


def create_reservation_expiries() -> tuple:
    now = utcnow()
    return (
        now + timedelta(minutes=settings.reservation_response_minutes),
        now + timedelta(hours=settings.reservation_lifetime_hours),
    )
