from __future__ import annotations
import hmac
import re
import uuid
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.config import settings
from app.models import (
    Ad, AdLocation, AdPhoto, AdStatus, Availability, BuyerLocation, Category, ChatMessage,
    Conversation, Favorite, Location, MaxConversationState, MaxInboundUpdate, MaxOutboundMessage,
    NotificationEvent, Reservation, ReservationStatus, Role, SellerLocation, User, utcnow,
)
from app.security import encrypt_phone
from app.services import (
    assert_seller_locations, create_reservation_expiries, ensure_reservation_capacity,
    get_user_location_ids, matching_buyer_location_ids, notify, require_role, set_user_location,
)
ButtonRows = list[list[dict[str, Any]]]
UPLOAD_DIRECTORY = Path('uploads')
def callback(text: str, payload: str) -> dict[str, str]:
    return {'type': 'callback', 'text': text, 'payload': payload}
def request_contact(text: str = 'Поделиться контактом') -> dict[str, str]:
    return {'type': 'request_contact', 'text': text}
def max_external_id(max_user_id: int | str) -> str:
    return 'max:' + str(max_user_id)
def _max_user_name(data: dict[str, Any]) -> str:
    full_name = ' '.join(part for part in [data.get('first_name'), data.get('last_name')] if isinstance(part, str) and part.strip())
    return full_name[:160] or 'Пользователь MAX'
def _message_attachments(update: dict[str, Any]) -> list[dict[str, Any]]:
    message = update.get('message') or {}
    body = message.get('body') or message.get('message') or {}
    attachments = body.get('attachments') or []
    return [item for item in attachments if isinstance(item, dict)]
def _message_text(update: dict[str, Any]) -> str:
    message = update.get('message') or {}
    body = message.get('body') or message.get('message') or {}
    return (body.get('text') or '').strip() if isinstance(body, dict) else ''
def _message_sender(update: dict[str, Any]) -> dict[str, Any] | None:
    message = update.get('message') or {}
    sender = message.get('sender')
    return sender if isinstance(sender, dict) else None
def _extract_actor(update: dict[str, Any]) -> dict[str, Any] | None:
    update_type = update.get('update_type')
    if update_type == 'message_callback':
        callback_data = update.get('callback') or {}
        user = callback_data.get('user')
        return user if isinstance(user, dict) else None
    if update_type == 'bot_started':
        user = update.get('user')
        return user if isinstance(user, dict) else None
    return _message_sender(update)
def _max_photo_attachment(attachment: dict[str, Any]) -> str | None:
    if attachment.get('type') != 'image':
        return None
    payload = attachment.get('payload') or {}
    url = payload.get('url') if isinstance(payload, dict) else None
    return url if isinstance(url, str) and url.startswith('https://') else None
def _contact_attachment(attachments: list[dict[str, Any]]) -> dict[str, Any] | None:
    for attachment in attachments:
        if attachment.get('type') == 'contact' and isinstance(attachment.get('payload'), dict):
            return attachment['payload']
    return None
def _verified_max_phone(contact: dict[str, Any]) -> str | None:
    if not settings.max_bot_token:
        return None
    vcf_info = contact.get('vcf_info')
    provided_hash = contact.get('hash')
    if not isinstance(vcf_info, str) or not isinstance(provided_hash, str):
        return None
    normalized_vcf = vcf_info.replace('\\r\\n', '\r\n')
    expected_hash = hmac.digest(settings.max_bot_token.encode(), normalized_vcf.encode(), 'sha256').hex()
    if not hmac.compare_digest(provided_hash.lower(), expected_hash):
        return None
    match = re.search(r'^TEL[^:]*:(.+)$', normalized_vcf, flags=re.MULTILINE)
    if not match:
        return None
    phone = ''.join(char for char in match.group(1) if char.isdigit() or char == '+')
    return phone if len(phone) >= 7 else None
def _ad_photo_attachment(storage_key: str) -> dict[str, Any] | None:
    if not settings.public_base_url or not storage_key.startswith('/uploads/'):
        return None
    return {'type': 'image', 'payload': {'url': settings.public_base_url + storage_key}}
def _download_max_photo(url: str) -> str:
    '''MAX image URLs are temporary, so retain an accepted image in local storage immediately.'''
    try:
        with httpx.Client(timeout=15, follow_redirects=True) as client:
            response = client.get(url)
            response.raise_for_status()
    except httpx.HTTPError as error:
        raise ValueError('Не удалось получить фото из MAX. Отправьте его ещё раз.') from error
    content_type = response.headers.get('content-type', '').split(';', 1)[0].lower()
    extensions = {'image/jpeg': '.jpg', 'image/png': '.png', 'image/gif': '.gif', 'image/webp': '.webp'}
    if content_type not in extensions or len(response.content) > 5 * 1024 * 1024:
        raise ValueError('Поддерживаются изображения JPG, PNG, GIF или WebP размером до 5 МБ.')
    UPLOAD_DIRECTORY.mkdir(exist_ok=True)
    key = '/uploads/' + uuid.uuid4().hex + extensions[content_type]
    (UPLOAD_DIRECTORY / key.removeprefix('/uploads/')).write_bytes(response.content)
    return key
class MaxBot:
    '''Conversation coordinator. It only persists changes and queues responses; no network calls occur here.'''
    def get_or_create_user(self, session: Session, actor: dict[str, Any]) -> User:
        max_user_id = actor.get('user_id')
        if not isinstance(max_user_id, int) and not (isinstance(max_user_id, str) and max_user_id.isdigit()):
            raise ValueError('В событии MAX отсутствует идентификатор пользователя.')
        external_id = max_external_id(max_user_id)
        user = session.scalar(select(User).where(User.external_id == external_id))
        if user is None:
            user = User(
                external_id=external_id,
                phone_ciphertext=encrypt_phone(''),
                name=_max_user_name(actor),
                roles=int(Role.BUYER),
                phone_verified=not settings.phone_verification_required,
            )
            session.add(user)
            session.flush()
        return user
    @staticmethod
    def get_state(session: Session, user: User) -> MaxConversationState:
        state = session.scalar(select(MaxConversationState).where(MaxConversationState.user_id == user.id))
        if state is None:
            state = MaxConversationState(user_id=user.id)
            session.add(state)
            session.flush()
        return state
    @staticmethod
    def set_state(state: MaxConversationState, name: str, data: dict[str, Any] | None = None) -> None:
        state.state = name
        state.data = data or {}
    @staticmethod
    def queue(
        session: Session,
        user: User,
        text: str,
        buttons: ButtonRows | None = None,
        attachments: list[dict[str, Any]] | None = None,
    ) -> None:
        session.add(MaxOutboundMessage(
            recipient_id=user.id,
            text=text[:4000],
            buttons=buttons or [],
            attachments=attachments or [],
        ))
    def _main_menu(self, session: Session, user: User, greeting: str | None = None) -> None:
        buttons: ButtonRows = [
            [callback('Каталог', 'menu:catalog'), callback('Избранное', 'menu:favorites')],
            [callback('Профиль', 'menu:profile'), callback('Чаты', 'menu:chats')],
        ]
        if user.has_role(Role.SELLER):
            buttons.insert(1, [callback('Разместить товар', 'menu:create_ad'), callback('Мои товары', 'menu:my_ads')])
            buttons.insert(2, [callback('Заявки на резерв', 'menu:reservations')])
        self.queue(session, user, greeting or 'Главное меню «Фермы».', buttons)
    def _request_contact(self, session: Session, user: User) -> None:
        state = self.get_state(session, user)
        self.set_state(state, 'awaiting_contact')
        self.queue(
            session,
            user,
            'Для регистрации подтвердите номер, привязанный к MAX. Нажмите кнопку ниже.',
            [[request_contact()]],
        )
    def _show_profile(self, session: Session, user: User) -> None:
        buyer_locations = sorted(get_user_location_ids(session, user.id, as_seller=False))
        seller_locations = sorted(get_user_location_ids(session, user.id, as_seller=True))
        roles = ', '.join(role.name.lower() for role in Role if user.has_role(role))
        phone_status = 'подтверждён' if user.phone_verified else 'не подтверждён'
        self.queue(
            session,
            user,
            f'Профиль: {user.name}\nРоли: {roles}\nТелефон: {phone_status}\nЛокации покупателя: {len(buyer_locations)}\nЛокации продавца: {len(seller_locations)}',
            [
                [callback('Локации', 'menu:locations'), callback('Роли', 'menu:roles')],
                [callback('Главное меню', 'menu:home')],
            ],
        )
    def _show_locations(self, session: Session, user: User, seller: bool) -> None:
        location_ids = get_user_location_ids(session, user.id, as_seller=seller)
        locations = session.scalars(select(Location).where(Location.id.in_(location_ids)).order_by(Location.name)).all() if location_ids else []
        role_name = 'продавца' if seller else 'покупателя'
        current = ', '.join(location.name for location in locations) or 'не выбраны'
        marker = 's' if seller else 'b'
        self.queue(
            session,
            user,
            f'Локации {role_name}: {current}\nВыберите пункт из списка или отправьте название сообщением.',
            [[callback('Искать локацию', f'location_search:{marker}')], [callback('Назад', 'menu:profile')]],
        )
    def _show_location_choices(self, session: Session, user: User, seller: bool, query: str | None = None) -> None:
        statement = select(Location).order_by(Location.name).limit(20)
        if query:
            statement = statement.where(Location.name.ilike(f'%{query.strip()}%'))
        locations = session.scalars(statement).all()
        marker = 's' if seller else 'b'
        buttons = [[callback(location.name[:40], f'location:{marker}:{location.id}')] for location in locations]
        buttons.append([callback('Назад', f'menu:locations:{marker}')])
        self.queue(session, user, 'Выберите локацию:' if locations else 'Локации не найдены.', buttons)
    def _show_categories(self, session: Session, user: User, prefix: str = 'browse') -> None:
        categories = session.scalars(select(Category).where(Category.is_active.is_(True)).order_by(Category.display_order, Category.name)).all()
        buttons = [[callback(category.name, f'{prefix}:{category.id}')] for category in categories]
        buttons.append([callback('Главное меню', 'menu:home')])
        self.queue(session, user, 'Выберите категорию:', buttons)
    def _visible_ads(self, session: Session, user: User, category_id: int | None = None) -> list[Ad]:
        location_ids = matching_buyer_location_ids(session, user.id)
        if not location_ids:
            return []
        statement = select(Ad).join(AdLocation).where(Ad.status == AdStatus.ACTIVE, AdLocation.location_id.in_(location_ids))
        if category_id:
            statement = statement.where(Ad.category_id == category_id)
        return session.scalars(statement.order_by(Ad.activated_at.desc(), Ad.id.desc()).distinct().limit(20)).all()
    def _show_ads(self, session: Session, user: User, category_id: int | None) -> None:
        ads = self._visible_ads(session, user, category_id)
        buttons = [[callback(f'{ad.title[:30]} — {ad.price} ₽/{ad.unit}', f'ad:{ad.id}')] for ad in ads]
        buttons.append([callback('Категории', 'menu:catalog')])
        text = 'Подходящие товары:' if ads else 'Для ваших локаций товаров пока нет. Добавьте локацию в профиле.'
        self.queue(session, user, text, buttons)
    def _show_ad(self, session: Session, user: User, ad_id: int) -> None:
        ad = session.get(Ad, ad_id)
        if ad is None or ad.status != AdStatus.ACTIVE or ad.seller_id == user.id:
            raise ValueError('Товар недоступен.')
        if not ({item.location_id for item in ad.locations} & matching_buyer_location_ids(session, user.id)):
            raise ValueError('Товар недоступен для ваших локаций.')
        favorite = session.get(Favorite, {'buyer_id': user.id, 'ad_id': ad.id}) is not None
        available = 'без ограничения' if ad.stock_quantity is None else str(ad.stock_quantity)
        locations = ', '.join(item.location.name for item in ad.locations)
        text = (
            f'{ad.title}\n{ad.price} ₽/{ad.unit}\nКатегория: {ad.category.name}\n'
            f'Продавец: {ad.seller.name}\nЛокации: {locations}\nВ наличии: {available}\n\n{ad.description or "Без описания"}'
        )
        attachments = [item for item in [_ad_photo_attachment(ad.photos[0].storage_key)] if item]
        self.queue(
            session,
            user,
            text,
            [[callback('Убрать из избранного' if favorite else 'В избранное', f'favorite:{ad.id}')], [callback('Зарезервировать', f'reserve:{ad.id}'), callback('Написать', f'conversation:{ad.id}')], [callback('Каталог', 'menu:catalog')]],
            attachments,
        )
    def _show_favorites(self, session: Session, user: User) -> None:
        ads = session.scalars(
            select(Ad).join(Favorite).where(Favorite.buyer_id == user.id, Ad.status == AdStatus.ACTIVE).order_by(Favorite.created_at.desc())
        ).all()
        buttons = [[callback(f'{ad.title[:30]} — {ad.price} ₽', f'ad:{ad.id}')] for ad in ads]
        buttons.append([callback('Главное меню', 'menu:home')])
        self.queue(session, user, 'Избранное:' if ads else 'В избранном пока нет товаров.', buttons)
    def _show_conversations(self, session: Session, user: User) -> None:
        conversations = session.scalars(
            select(Conversation).where((Conversation.buyer_id == user.id) | (Conversation.seller_id == user.id)).order_by(Conversation.created_at.desc()).limit(20)
        ).all()
        buttons: ButtonRows = []
        for item in conversations:
            ad = session.get(Ad, item.ad_id)
            buttons.append([callback((ad.title if ad else f'Товар #{item.ad_id}')[:40], f'chat:{item.id}')])
        buttons.append([callback('Главное меню', 'menu:home')])
        self.queue(session, user, 'Ваши чаты:' if conversations else 'У вас пока нет чатов.', buttons)
    def _show_reservations(self, session: Session, user: User) -> None:
        reservations = session.scalars(
            select(Reservation).join(Ad).where(Ad.seller_id == user.id, Reservation.status == ReservationStatus.PENDING).order_by(Reservation.created_at)
        ).all()
        buttons: ButtonRows = []
        for reservation in reservations:
            ad = session.get(Ad, reservation.ad_id)
            buyer = session.get(User, reservation.buyer_id)
            label = f'{ad.title if ad else "Товар"}: {reservation.quantity} ({buyer.name if buyer else "покупатель"})'
            buttons.append([callback('Подтвердить: ' + label[:30], f'reservation:{reservation.id}:yes')])
            buttons.append([callback('Отклонить: ' + label[:30], f'reservation:{reservation.id}:no')])
        buttons.append([callback('Главное меню', 'menu:home')])
        self.queue(session, user, 'Ожидающие заявки:' if reservations else 'Новых заявок на резерв нет.', buttons)
    def _show_my_ads(self, session: Session, user: User) -> None:
        ads = session.scalars(select(Ad).where(Ad.seller_id == user.id).order_by(Ad.created_at.desc()).limit(20)).all()
        buttons: ButtonRows = []
        for ad in ads:
            action = 'Отправить на модерацию' if ad.status in {AdStatus.DRAFT, AdStatus.REJECTED} else 'Открыть'
            buttons.append([callback(f'{action}: {ad.title[:28]} ({ad.status.value})', f'my_ad:{ad.id}')])
        buttons.append([callback('Разместить товар', 'menu:create_ad'), callback('Главное меню', 'menu:home')])
        self.queue(session, user, 'Мои товары:' if ads else 'У вас пока нет товаров.', buttons)
    def _start_ad(self, session: Session, user: User) -> None:
        require_role(user, Role.SELLER)
        if settings.phone_verification_required and not user.phone_verified:
            self._request_contact(session, user)
            return
        if not get_user_location_ids(session, user.id, as_seller=True):
            self.queue(session, user, 'Сначала добавьте хотя бы одну локацию продавца в профиле.', [[callback('Профиль', 'menu:profile')]])
            return
        state = self.get_state(session, user)
        self.set_state(state, 'ad_category', {})
        self._show_categories(session, user, prefix='ad_category')
    def _finish_ad(self, session: Session, user: User, state: MaxConversationState) -> None:
        data = state.data
        photos = data.get('photos') or []
        if not photos:
            raise ValueError('Добавьте хотя бы одно фото товара.')
        ad = Ad(
            seller_id=user.id,
            title=data['title'],
            description=data.get('description', ''),
            price=Decimal(data['price']),
            unit=data['unit'],
            stock_quantity=Decimal(data['stock_quantity']) if data.get('stock_quantity') else None,
            category_id=int(data['category_id']),
            availability=Availability.IN_STOCK,
            status=AdStatus.DRAFT,
        )
        location_id = int(data['location_id'])
        assert_seller_locations(session, user.id, [location_id])
        ad.locations = [AdLocation(location_id=location_id)]
        ad.photos = [AdPhoto(storage_key=key, display_order=index) for index, key in enumerate(photos)]
        session.add(ad)
        session.flush()
        self.set_state(state, 'menu')
        self.queue(
            session,
            user,
            f'Черновик «{ad.title}» создан. Проверьте данные и отправьте его на модерацию.',
            [[callback('Отправить на модерацию', f'submit_ad:{ad.id}')], [callback('Мои товары', 'menu:my_ads')]],
        )
    def _handle_text(self, session: Session, user: User, text: str, attachments: list[dict[str, Any]]) -> None:
        state = self.get_state(session, user)
        contact = _contact_attachment(attachments)
        if contact:
            phone = _verified_max_phone(contact)
            if phone:
                user.phone_ciphertext = encrypt_phone(phone)
                user.phone_verified = True
                self.set_state(state, 'menu')
                self._main_menu(session, user, 'Номер подтверждён. Добро пожаловать в «Ферму».')
            else:
                self._request_contact(session, user)
                self.queue(session, user, 'Контакт не прошёл проверку. Поделитесь номером кнопкой бота, а не вручную.')
            return
        if text.lower() in {'/start', '/menu', 'меню'}:
            if not user.phone_verified:
                self._request_contact(session, user)
            else:
                self.set_state(state, 'menu')
                self._main_menu(session, user)
            return
        if state.state == 'location_search_b' or state.state == 'location_search_s':
            self._show_location_choices(session, user, state.state.endswith('_s'), text)
            return
        if state.state == 'awaiting_reservation_quantity':
            try:
                quantity = Decimal(text.replace(',', '.'))
                if quantity <= 0:
                    raise InvalidOperation
            except InvalidOperation:
                self.queue(session, user, 'Введите положительное количество числом, например: 2.5')
                return
            ad = session.get(Ad, int(state.data['ad_id']))
            if ad is None or ad.status != AdStatus.ACTIVE:
                raise ValueError('Товар больше недоступен.')
            ensure_reservation_capacity(session, ad, quantity)
            response_deadline, _ = create_reservation_expiries()
            reservation = Reservation(ad_id=ad.id, buyer_id=user.id, quantity=quantity, status=ReservationStatus.PENDING, response_deadline_at=response_deadline)
            session.add(reservation)
            session.flush()
            notify(session, ad.seller_id, 'reservation_requested', {'reservation_id': reservation.id, 'ad_id': ad.id, 'buyer_name': user.name, 'quantity': str(quantity)})
            self.set_state(state, 'menu')
            self.queue(session, user, 'Заявка на резерв отправлена продавцу.', [[callback('Главное меню', 'menu:home')]])
            return
        if state.state == 'awaiting_chat_message':
            conversation = session.get(Conversation, int(state.data['conversation_id']))
            if conversation is None or user.id not in {conversation.buyer_id, conversation.seller_id} or conversation.closed_at:
                raise ValueError('Этот чат недоступен.')
            if not text:
                self.queue(session, user, 'Отправьте текст сообщения.')
                return
            message = ChatMessage(conversation_id=conversation.id, sender_id=user.id, body=text[:3000])
            session.add(message)
            recipient_id = conversation.seller_id if user.id == conversation.buyer_id else conversation.buyer_id
            notify(session, recipient_id, 'chat_message', {'conversation_id': conversation.id, 'sender_id': user.id})
            self.queue(session, user, 'Сообщение отправлено.', [[callback('К чатам', 'menu:chats')]])
            return
        if state.state.startswith('ad_'):
            self._handle_ad_text(session, user, state, text, attachments)
            return
        self._main_menu(session, user, 'Используйте кнопки меню или отправьте /menu.')
    def _handle_ad_text(self, session: Session, user: User, state: MaxConversationState, text: str, attachments: list[dict[str, Any]]) -> None:
        data = dict(state.data)
        if state.state == 'ad_title':
            if not 1 <= len(text) <= 200:
                self.queue(session, user, 'Название должно содержать от 1 до 200 символов.')
                return
            data['title'] = text
            self.set_state(state, 'ad_description', data)
            self.queue(session, user, 'Опишите товар (до 1500 символов).')
            return
        if state.state == 'ad_description':
            if len(text) > 1500:
                self.queue(session, user, 'Описание слишком длинное.')
                return
            data['description'] = text
            self.set_state(state, 'ad_price', data)
            self.queue(session, user, 'Укажите цену в рублях, например: 120.50')
            return
        if state.state == 'ad_price':
            try:
                price = Decimal(text.replace(',', '.'))
                if price <= 0 or price.as_tuple().exponent < -2:
                    raise InvalidOperation
            except InvalidOperation:
                self.queue(session, user, 'Введите цену числом, не более двух знаков после запятой.')
                return
            data['price'] = str(price.quantize(Decimal('0.01')))
            self.set_state(state, 'ad_unit', data)
            self.queue(session, user, 'Укажите единицу измерения, например: кг, литр или упаковка.')
            return
        if state.state == 'ad_unit':
            if not 1 <= len(text) <= 30:
                self.queue(session, user, 'Единица измерения должна содержать от 1 до 30 символов.')
                return
            data['unit'] = text
            self.set_state(state, 'ad_stock', data)
            self.queue(session, user, 'Укажите остаток числом до трёх знаков после запятой или отправьте «без ограничений».')
            return
        if state.state == 'ad_stock':
            if text.lower() not in {'без ограничений', 'нет'}:
                try:
                    quantity = Decimal(text.replace(',', '.'))
                    if quantity <= 0 or quantity.as_tuple().exponent < -3:
                        raise InvalidOperation
                    data['stock_quantity'] = str(quantity.quantize(Decimal('0.001')))
                except InvalidOperation:
                    self.queue(session, user, 'Введите положительный остаток или «без ограничений».')
                    return
            else:
                data['stock_quantity'] = None
            self.set_state(state, 'ad_location', data)
            location_ids = get_user_location_ids(session, user.id, as_seller=True)
            locations = session.scalars(select(Location).where(Location.id.in_(location_ids)).order_by(Location.name)).all()
            self.queue(session, user, 'Выберите локацию товара:', [[callback(location.name, f'ad_location:{location.id}')] for location in locations])
            return
        if state.state == 'ad_photo':
            urls = [url for url in (_max_photo_attachment(item) for item in attachments) if url]
            if not urls:
                self.queue(session, user, 'Отправьте изображение товара из галереи MAX.')
                return
            photos = list(data.get('photos') or [])
            for url in urls:
                if len(photos) == 5:
                    break
                photos.append(_download_max_photo(url))
            data['photos'] = photos
            self.set_state(state, 'ad_photo', data)
            self.queue(session, user, f'Добавлено фото: {len(photos)}/5.', [[callback('Готово', 'ad_finish')]])
            return
        self.set_state(state, 'menu')
        self._main_menu(session, user)
    def _handle_callback(self, session: Session, user: User, payload: str) -> None:
        state = self.get_state(session, user)
        if payload == 'menu:home':
            self.set_state(state, 'menu')
            self._main_menu(session, user)
            return
        if payload == 'menu:catalog':
            self.set_state(state, 'menu')
            self._show_categories(session, user)
            return
        if payload == 'menu:favorites':
            self._show_favorites(session, user)
            return
        if payload == 'menu:profile':
            self._show_profile(session, user)
            return
        if payload == 'menu:locations':
            self.queue(session, user, 'Управление локациями:', [[callback('Как покупатель', 'menu:locations:b')], [callback('Как продавец', 'menu:locations:s')], [callback('Назад', 'menu:profile')]])
            return
        if payload.startswith('menu:locations:'):
            self._show_locations(session, user, payload.rsplit(':', 1)[1] == 's')
            return
        if payload == 'menu:roles':
            self.queue(session, user, 'Выберите роль:', [[callback('Стать продавцом', 'role:add_seller')], [callback('Оставить только покупателя', 'role:remove_seller')], [callback('Назад', 'menu:profile')]])
            return
        if payload == 'role:add_seller':
            user.add_role(Role.SELLER)
            self._main_menu(session, user, 'Роль продавца добавлена.')
            return
        if payload == 'role:remove_seller':
            user.remove_role(Role.SELLER)
            for ad in session.scalars(select(Ad).where(Ad.seller_id == user.id, Ad.status != AdStatus.DELETED)).all():
                ad.status = AdStatus.DELETED
            self._main_menu(session, user, 'Роль продавца отключена. Активные объявления сохранены до решения администратора.')
            return
        if payload == 'menu:create_ad':
            self._start_ad(session, user)
            return
        if payload == 'menu:my_ads':
            require_role(user, Role.SELLER)
            self._show_my_ads(session, user)
            return
        if payload == 'menu:reservations':
            require_role(user, Role.SELLER)
            self._show_reservations(session, user)
            return
        if payload == 'menu:chats':
            self._show_conversations(session, user)
            return
        if payload.startswith('location_search:'):
            marker = payload.rsplit(':', 1)[1]
            self.set_state(state, 'location_search_' + marker)
            self.queue(session, user, 'Отправьте название города, района или населённого пункта.')
            return
        if payload.startswith('location:'):
            _, marker, raw_location_id = payload.split(':', 2)
            seller = marker == 's'
            if seller:
                require_role(user, Role.SELLER)
            location = session.get(Location, int(raw_location_id))
            if location is None:
                raise ValueError('Локация не найдена.')
            set_user_location(session, user, location.id, as_seller=seller)
            self._show_locations(session, user, seller)
            return
        if payload.startswith('browse:'):
            self._show_ads(session, user, int(payload.split(':', 1)[1]))
            return
        if payload.startswith('ad:'):
            self._show_ad(session, user, int(payload.split(':', 1)[1]))
            return
        if payload.startswith('favorite:'):
            ad_id = int(payload.split(':', 1)[1])
            favorite = session.get(Favorite, {'buyer_id': user.id, 'ad_id': ad_id})
            if favorite:
                session.delete(favorite)
                self.queue(session, user, 'Товар убран из избранного.')
            else:
                session.add(Favorite(buyer_id=user.id, ad_id=ad_id))
                self.queue(session, user, 'Товар добавлен в избранное.')
            self._show_ad(session, user, ad_id)
            return
        if payload.startswith('reserve:'):
            ad_id = int(payload.split(':', 1)[1])
            self.set_state(state, 'awaiting_reservation_quantity', {'ad_id': ad_id})
            self.queue(session, user, 'Введите нужное количество товара.')
            return
        if payload.startswith('conversation:'):
            ad = session.get(Ad, int(payload.split(':', 1)[1]))
            if ad is None or ad.seller_id == user.id:
                raise ValueError('Чат недоступен.')
            conversation = session.scalar(select(Conversation).where(Conversation.ad_id == ad.id, Conversation.buyer_id == user.id, Conversation.seller_id == ad.seller_id))
            if conversation is None:
                conversation = Conversation(ad_id=ad.id, buyer_id=user.id, seller_id=ad.seller_id)
                session.add(conversation)
                session.flush()
            self.set_state(state, 'awaiting_chat_message', {'conversation_id': conversation.id})
            self.queue(session, user, 'Напишите сообщение продавцу. Номер телефона не будет передан.')
            return
        if payload.startswith('chat:'):
            conversation = session.get(Conversation, int(payload.split(':', 1)[1]))
            if conversation is None or user.id not in {conversation.buyer_id, conversation.seller_id}:
                raise ValueError('Чат недоступен.')
            messages = session.scalars(select(ChatMessage).where(ChatMessage.conversation_id == conversation.id).order_by(ChatMessage.created_at.desc()).limit(5)).all()
            history = '\n'.join(f'{"Вы" if message.sender_id == user.id else "Собеседник"}: {message.body}' for message in reversed(messages)) or 'Сообщений пока нет.'
            self.set_state(state, 'awaiting_chat_message', {'conversation_id': conversation.id})
            self.queue(session, user, history + '\n\nОтправьте новое сообщение.')
            return
        if payload.startswith('reservation:'):
            _, raw_reservation_id, decision = payload.split(':', 2)
            reservation = session.get(Reservation, int(raw_reservation_id))
            if reservation is None or reservation.ad.seller_id != user.id or reservation.status != ReservationStatus.PENDING:
                raise ValueError('Заявка уже обработана или недоступна.')
            reservation.responded_at = utcnow()
            if decision == 'yes':
                _, expires_at = create_reservation_expiries()
                reservation.status = ReservationStatus.CONFIRMED
                reservation.expires_at = expires_at
                event = 'reservation_confirmed'
                response = 'Резерв подтверждён.'
            else:
                reservation.status = ReservationStatus.DECLINED
                event = 'reservation_declined'
                response = 'Резерв отклонён.'
            notify(session, reservation.buyer_id, event, {'reservation_id': reservation.id, 'ad_id': reservation.ad_id})
            self.queue(session, user, response)
            self._show_reservations(session, user)
            return
        if payload.startswith('ad_category:'):
            category = session.get(Category, int(payload.split(':', 1)[1]))
            if category is None or not category.is_active:
                raise ValueError('Категория недоступна.')
            self.set_state(state, 'ad_title', {'category_id': category.id})
            self.queue(session, user, 'Введите название товара.')
            return
        if payload.startswith('ad_location:'):
            location_id = int(payload.split(':', 1)[1])
            if location_id not in get_user_location_ids(session, user.id, as_seller=True):
                raise ValueError('Эта локация не относится к вашему профилю продавца.')
            data = dict(state.data)
            data['location_id'] = location_id
            data['photos'] = []
            self.set_state(state, 'ad_photo', data)
            self.queue(session, user, 'Отправьте от 1 до 5 фотографий товара. После последней нажмите «Готово».')
            return
        if payload == 'ad_finish':
            if state.state != 'ad_photo':
                raise ValueError('Сначала заполните данные товара.')
            self._finish_ad(session, user, state)
            return
        if payload.startswith('submit_ad:') or payload.startswith('my_ad:'):
            ad_id = int(payload.split(':', 1)[1])
            ad = session.get(Ad, ad_id)
            if ad is None or ad.seller_id != user.id:
                raise ValueError('Товар недоступен.')
            if payload.startswith('submit_ad:') or ad.status in {AdStatus.DRAFT, AdStatus.REJECTED}:
                if settings.phone_verification_required and not user.phone_verified:
                    self._request_contact(session, user)
                    return
                if not ad.photos:
                    raise ValueError('Для отправки нужно хотя бы одно фото.')
                ad.status = AdStatus.PENDING_MODERATION
                ad.rejection_reason = None
                notify(session, user.id, 'ad_submitted', {'ad_id': ad.id})
                self.queue(session, user, 'Объявление отправлено на модерацию.')
            else:
                self.queue(session, user, f'Товар «{ad.title}»: статус {ad.status.value}.')
            return
        self._main_menu(session, user, 'Эта кнопка больше не актуальна. Откройте меню снова.')
    def process_update(self, session: Session, inbound: MaxInboundUpdate) -> tuple[str, str] | None:
        update = inbound.payload
        update_type = update.get('update_type')
        if update_type not in {'bot_started', 'message_created', 'message_callback'}:
            inbound.processed_at = utcnow()
            return None
        actor = _extract_actor(update)
        if not actor or actor.get('is_bot'):
            inbound.processed_at = utcnow()
            return None
        user = self.get_or_create_user(session, actor)
        try:
            if update_type == 'bot_started':
                if user.phone_verified:
                    self._main_menu(session, user, 'С возвращением в «Ферму».')
                else:
                    self._request_contact(session, user)
            elif update_type == 'message_callback':
                callback_data = update.get('callback') or {}
                payload = callback_data.get('payload')
                if isinstance(payload, str):
                    self._handle_callback(session, user, payload)
                else:
                    self._main_menu(session, user, 'Кнопка не содержит действия.')
            else:
                self._handle_text(session, user, _message_text(update), _message_attachments(update))
        except HTTPException as error:
            self.queue(session, user, str(error.detail))
        except (ValueError, InvalidOperation) as error:
            self.queue(session, user, str(error))
        inbound.processed_at = utcnow()
        callback_data = update.get('callback') or {}
        callback_id = callback_data.get('callback_id')
        return (callback_id, user.external_id) if isinstance(callback_id, str) else None
def notification_content(session: Session, event: NotificationEvent) -> tuple[str, ButtonRows]:
    payload = event.payload or {}
    ad_id = payload.get('ad_id')
    ad = session.get(Ad, ad_id) if isinstance(ad_id, int) else None
    ad_name = f' «{ad.title}»' if ad else ''
    messages = {
        'ad_submitted': f'Объявление{ad_name} отправлено на модерацию.',
        'ad_approved': f'Объявление{ad_name} одобрено и опубликовано.',
        'ad_rejected': f'Объявление{ad_name} отклонено. Причина: {payload.get("reason", "не указана")}',
        'ad_expiring_soon': f'Срок публикации объявления{ad_name} скоро закончится.',
        'ad_expired': f'Срок публикации объявления{ad_name} закончился.',
        'favorite_ad_expiring_soon': f'Товар из избранного{ad_name} скоро будет снят с публикации.',
        'reservation_requested': f'Новая заявка на резерв{ad_name}: {payload.get("quantity", "")} от {payload.get("buyer_name", "покупателя")}.',
        'reservation_confirmed': f'Ваш резерв{ad_name} подтверждён.',
        'reservation_declined': f'Ваш резерв{ad_name} отклонён.',
        'reservation_cancelled': f'Резерв{ad_name} отменён покупателем.',
        'reservation_expired': 'Срок резерва истёк.',
        'chat_message': 'Новое сообщение в чате по товару.',
        'broadcast': str(payload.get('body', 'Новое сообщение от администрации.')),
    }
    text = messages.get(event.event_type, 'У вас новое событие в «Ферме».')
    buttons: ButtonRows = [[callback('Открыть товар', f'ad:{ad_id}')]] if ad and event.event_type not in {'ad_submitted', 'ad_approved', 'ad_rejected'} else []
    if event.event_type == 'reservation_requested' and isinstance(payload.get('reservation_id'), int):
        buttons = [[callback('Открыть заявки', 'menu:reservations')]]
    elif event.event_type == 'chat_message' and isinstance(payload.get('conversation_id'), int):
        buttons = [[callback('Открыть чат', f'chat:{payload["conversation_id"]}')]]
    return text, buttons
def queue_pending_notifications(session: Session, limit: int = 100) -> int:
    'Persist notification events in the outbox exactly once, even with several workers.'
    events = session.scalars(
        select(NotificationEvent).join(User).where(
            NotificationEvent.delivered_at.is_(None),
            User.external_id.like('max:%'),
        ).order_by(NotificationEvent.id).limit(limit)
    ).all()
    count = 0
    for event in events:
        try:
            with session.begin_nested():
                exists = session.scalar(
                    select(MaxOutboundMessage.id).where(MaxOutboundMessage.notification_event_id == event.id)
                )
                if exists:
                    continue
                text, buttons = notification_content(session, event)
                session.add(MaxOutboundMessage(
                    recipient_id=event.recipient_id,
                    notification_event_id=event.id,
                    text=text,
                    buttons=buttons,
                    attachments=[],
                ))
                session.flush()
        except IntegrityError:
            # Another worker inserted this event into the outbox first.
            continue
        count += 1
    return count
