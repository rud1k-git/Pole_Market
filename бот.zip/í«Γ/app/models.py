from __future__ import annotations

import enum
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy import (
    JSON, Boolean, CheckConstraint, DateTime, Enum, ForeignKey, Integer, Numeric,
    String, Text, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utcnow() -> datetime:
    '''Use naive UTC consistently; PostgreSQL and SQLite then behave identically.'''
    return datetime.now(UTC).replace(tzinfo=None)


class Role(enum.IntFlag):
    BUYER = 1
    SELLER = 2
    ADMIN = 4


class LocationKind(str, enum.Enum):
    CITY = 'city'
    DISTRICT = 'district'
    LOCALITY = 'locality'


class AdStatus(str, enum.Enum):
    DRAFT = 'draft'
    PENDING_MODERATION = 'pending_moderation'
    AWAITING_PAYMENT = 'awaiting_payment'
    ACTIVE = 'active'
    EXPIRED = 'expired'
    REJECTED = 'rejected'
    DELETED = 'deleted'


class Availability(str, enum.Enum):
    IN_STOCK = 'in_stock'
    PREORDER = 'preorder'


class Fulfillment(str, enum.Enum):
    PICKUP = 'pickup'
    DELIVERY = 'delivery'
    BOTH = 'both'


class ReservationStatus(str, enum.Enum):
    PENDING = 'pending'
    CONFIRMED = 'confirmed'
    DECLINED = 'declined'
    CANCELLED = 'cancelled'
    EXPIRED = 'expired'


class User(Base):
    __tablename__ = 'users'

    id: Mapped[int] = mapped_column(primary_key=True)
    # External identity: local users use local-*; MAX users use max:<user_id>.
    external_id: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    phone_ciphertext: Mapped[str] = mapped_column(Text)
    phone_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    name: Mapped[str] = mapped_column(String(160))
    avatar_url: Mapped[str | None] = mapped_column(String(500))
    farm_name: Mapped[str | None] = mapped_column(String(200))
    roles: Mapped[int] = mapped_column(Integer, default=int(Role.BUYER), nullable=False)
    admin_password_hash: Mapped[str | None] = mapped_column(String(512))
    is_blocked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

    ads: Mapped[list[Ad]] = relationship(back_populates='seller', foreign_keys='Ad.seller_id')

    def has_role(self, role: Role) -> bool:
        return bool(Role(self.roles) & role)

    def add_role(self, role: Role) -> None:
        self.roles = int(Role(self.roles) | role)

    def remove_role(self, role: Role) -> None:
        self.roles = int(Role(self.roles) & ~role)


class PhoneVerification(Base):
    __tablename__ = 'phone_verifications'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    code_hash: Mapped[str] = mapped_column(String(128))
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class Location(Base):
    __tablename__ = 'locations'

    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[LocationKind] = mapped_column(Enum(LocationKind), index=True)
    name: Mapped[str] = mapped_column(String(250), index=True)
    latitude: Mapped[Decimal] = mapped_column(Numeric(9, 6))
    longitude: Mapped[Decimal] = mapped_column(Numeric(9, 6))
    parent_id: Mapped[int | None] = mapped_column(ForeignKey('locations.id'), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

    parent: Mapped[Location | None] = relationship(remote_side='Location.id')

    __table_args__ = (UniqueConstraint('kind', 'name', 'parent_id', name='uq_location_name_parent'),)


class LocationNeighbour(Base):
    __tablename__ = 'location_neighbours'

    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id', ondelete='CASCADE'), primary_key=True)
    neighbour_id: Mapped[int] = mapped_column(ForeignKey('locations.id', ondelete='CASCADE'), primary_key=True)

    __table_args__ = (CheckConstraint('location_id <> neighbour_id', name='ck_distinct_neighbours'),)


class SellerLocation(Base):
    __tablename__ = 'seller_locations'

    seller_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id', ondelete='CASCADE'), primary_key=True)


class BuyerLocation(Base):
    __tablename__ = 'buyer_locations'

    buyer_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id', ondelete='CASCADE'), primary_key=True)


class Category(Base):
    __tablename__ = 'categories'

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    display_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class Ad(Base):
    __tablename__ = 'ads'

    id: Mapped[int] = mapped_column(primary_key=True)
    seller_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    title: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(String(1500))
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    unit: Mapped[str] = mapped_column(String(30))
    # Stock was implicit in the brief, but is needed for partial reservations.
    stock_quantity: Mapped[Decimal | None] = mapped_column(Numeric(12, 3))
    category_id: Mapped[int] = mapped_column(ForeignKey('categories.id'), index=True)
    status: Mapped[AdStatus] = mapped_column(Enum(AdStatus), default=AdStatus.DRAFT, index=True)
    availability: Mapped[Availability] = mapped_column(Enum(Availability), default=Availability.IN_STOCK)
    fulfillment: Mapped[Fulfillment] = mapped_column(Enum(Fulfillment), default=Fulfillment.PICKUP)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True, nullable=False)
    activated_at: Mapped[datetime | None] = mapped_column(DateTime)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    expiry_warning_sent: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    moderated_by_id: Mapped[int | None] = mapped_column(ForeignKey('users.id'))
    rejection_reason: Mapped[str | None] = mapped_column(String(1000))

    seller: Mapped[User] = relationship(back_populates='ads', foreign_keys=[seller_id])
    category: Mapped[Category] = relationship()
    photos: Mapped[list[AdPhoto]] = relationship(back_populates='ad', cascade='all, delete-orphan')
    locations: Mapped[list[AdLocation]] = relationship(back_populates='ad', cascade='all, delete-orphan')
    reservations: Mapped[list[Reservation]] = relationship(back_populates='ad')


class AdPhoto(Base):
    __tablename__ = 'ad_photos'

    id: Mapped[int] = mapped_column(primary_key=True)
    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id', ondelete='CASCADE'), index=True)
    storage_key: Mapped[str] = mapped_column(String(500))
    display_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    ad: Mapped[Ad] = relationship(back_populates='photos')


class AdLocation(Base):
    __tablename__ = 'ad_locations'

    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id', ondelete='CASCADE'), primary_key=True)
    location_id: Mapped[int] = mapped_column(ForeignKey('locations.id'), primary_key=True, index=True)

    ad: Mapped[Ad] = relationship(back_populates='locations')
    location: Mapped[Location] = relationship()


class Reservation(Base):
    __tablename__ = 'reservations'

    id: Mapped[int] = mapped_column(primary_key=True)
    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id'), index=True)
    buyer_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    quantity: Mapped[Decimal] = mapped_column(Numeric(12, 3))
    status: Mapped[ReservationStatus] = mapped_column(Enum(ReservationStatus), default=ReservationStatus.PENDING, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    response_deadline_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime)
    responded_at: Mapped[datetime | None] = mapped_column(DateTime)

    ad: Mapped[Ad] = relationship(back_populates='reservations')
    buyer: Mapped[User] = relationship(foreign_keys=[buyer_id])


class Conversation(Base):
    __tablename__ = 'conversations'

    id: Mapped[int] = mapped_column(primary_key=True)
    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id'), index=True)
    buyer_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    seller_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)

    __table_args__ = (UniqueConstraint('ad_id', 'buyer_id', 'seller_id', name='uq_conversation_participants'),)


class ChatMessage(Base):
    __tablename__ = 'chat_messages'

    id: Mapped[int] = mapped_column(primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey('conversations.id', ondelete='CASCADE'), index=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    body: Mapped[str] = mapped_column(String(3000))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class Complaint(Base):
    __tablename__ = 'complaints'

    id: Mapped[int] = mapped_column(primary_key=True)
    ad_id: Mapped[int | None] = mapped_column(ForeignKey('ads.id'), index=True)
    reporter_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    text: Mapped[str] = mapped_column(String(1500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)


class ModerationLog(Base):
    __tablename__ = 'moderation_log'

    id: Mapped[int] = mapped_column(primary_key=True)
    moderator_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    action: Mapped[str] = mapped_column(String(100), index=True)
    target_type: Mapped[str] = mapped_column(String(50))
    target_id: Mapped[int] = mapped_column(Integer, index=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class NotificationEvent(Base):
    __tablename__ = 'notification_events'

    id: Mapped[int] = mapped_column(primary_key=True)
    recipient_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class MaxInboundUpdate(Base):
    '''Raw webhook update retained for deduplication and restart-safe processing.'''
    __tablename__ = 'max_inbound_updates'
    id: Mapped[int] = mapped_column(primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    update_type: Mapped[str] = mapped_column(String(100), index=True)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_error: Mapped[str | None] = mapped_column(String(1000))
    processed_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    failed_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    claim_token: Mapped[str | None] = mapped_column(String(32), index=True)
    claim_expires_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
class MaxConversationState(Base):
    '''Per-user bot state; it survives process restarts and webhook retries.'''
    __tablename__ = 'max_conversation_states'
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), unique=True, index=True)
    state: Mapped[str] = mapped_column(String(100), default='menu', nullable=False)
    data: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow, nullable=False)
class MaxOutboundMessage(Base):
    '''Transactional outbox for MAX UI replies and persisted domain notifications.'''
    __tablename__ = 'max_outbound_messages'
    id: Mapped[int] = mapped_column(primary_key=True)
    recipient_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), index=True)
    notification_event_id: Mapped[int | None] = mapped_column(
        ForeignKey('notification_events.id', ondelete='CASCADE'), unique=True, index=True,
    )
    text: Mapped[str] = mapped_column(String(4000), nullable=False)
    buttons: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    attachments: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_error: Mapped[str | None] = mapped_column(String(1000))
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    failed_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    next_attempt_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    claim_token: Mapped[str | None] = mapped_column(String(32), index=True)
    claim_expires_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)

class Favorite(Base):
    __tablename__ = 'favorites'

    buyer_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id', ondelete='CASCADE'), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)


class PaymentStatus(str, enum.Enum):
    PENDING = 'pending'
    SUCCEEDED = 'succeeded'
    FAILED = 'failed'
    CANCELLED = 'cancelled'


class Payment(Base):
    '''Reserved schema for the future verified SBP webhook integration.'''

    __tablename__ = 'payments'

    id: Mapped[int] = mapped_column(primary_key=True)
    ad_id: Mapped[int] = mapped_column(ForeignKey('ads.id'), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    status: Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.PENDING, index=True)
    purpose: Mapped[str] = mapped_column(String(200), unique=True)
    external_transaction_id: Mapped[str | None] = mapped_column(String(200), unique=True)
    qr_code_url: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, nullable=False)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime)
