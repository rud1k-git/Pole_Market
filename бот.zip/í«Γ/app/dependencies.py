from __future__ import annotations

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.database import get_session
from app.models import Role, User
from app.security import decode_access_token


bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    session: Session = Depends(get_session),
) -> User:
    if credentials is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Bearer token required')
    payload = decode_access_token(credentials.credentials)
    subject = payload.get('sub')
    if not subject or not str(subject).isdigit():
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid access token subject')
    user = session.get(User, int(subject))
    if user is None or user.is_blocked:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='User is unavailable')
    return user


def ensure_role(user: User, role: Role) -> None:
    if not user.has_role(role):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='Insufficient role')
