import os
import hmac
from dataclasses import replace

import httpx
import pytest
from pathlib import Path

os.environ['FERMA_DATABASE_URL'] = 'sqlite:///./test_ferma.db'
os.environ['FERMA_ENVIRONMENT'] = 'development'
os.environ['FERMA_BOOTSTRAP_SECRET'] = 'test-bootstrap-secret'

from fastapi.testclient import TestClient

from app.database import Base, SessionLocal, engine
import app.main as main_module
import app.max_bot as max_bot_module
import app.integrations.messenger as messenger_module
from app.integrations.messenger import MaxApiError, MaxMessenger
from app.main import (
    app, claim_max_messages, mark_max_message_delivered, max_message_data, process_max_inbound_updates,
)
from app.models import MaxInboundUpdate, MaxOutboundMessage, NotificationEvent, User, utcnow


def headers(token: str) -> dict[str, str]:
    return {'Authorization': 'Bearer ' + token}


def register(client: TestClient, external_id: str, roles: list[str]) -> str:
    response = client.post('/api/v1/auth/register', json={
        'external_id': external_id,
        'phone': '+79990000000',
        'name': external_id,
        'roles': roles,
    })
    assert response.status_code == 201, response.text
    return response.json()['access_token']


def test_ad_lifecycle_reservation_and_proxy_chat() -> None:
    Path('test_ferma.db').unlink(missing_ok=True)
    Base.metadata.drop_all(bind=engine)
    with TestClient(app) as client:
        seller_token = register(client, 'seller-local', ['seller', 'buyer'])
        buyer_token = register(client, 'buyer-local', ['buyer'])

        admin_response = client.post('/api/v1/auth/bootstrap-admin', json={
            'external_id': 'seller-local',
            'password': 'secure-admin-password',
            'bootstrap_secret': 'test-bootstrap-secret',
        })
        assert admin_response.status_code == 200, admin_response.text
        admin_token = admin_response.json()['access_token']

        location_response = client.post('/api/v1/admin/locations', headers=headers(admin_token), json={
            'kind': 'city', 'name': 'Тестоград', 'latitude': 55.75, 'longitude': 37.62,
        })
        assert location_response.status_code == 201, location_response.text
        location_id = location_response.json()['id']

        assert client.put('/api/v1/users/me/locations/' + str(location_id) + '?seller=true', headers=headers(seller_token)).status_code == 200
        assert client.put('/api/v1/users/me/locations/' + str(location_id), headers=headers(buyer_token)).status_code == 200

        verification_response = client.post('/api/v1/auth/phone-verifications', headers=headers(seller_token))
        assert verification_response.status_code == 200
        code = verification_response.json()['development_code']
        assert client.post('/api/v1/auth/phone-verifications/' + code, headers=headers(seller_token)).status_code == 200

        upload_response = client.post(
            '/api/v1/uploads/photos',
            headers=headers(seller_token),
            files=[('files', ('milk.png', b'not-a-real-png-but-a-valid-upload', 'image/png'))],
        )
        assert upload_response.status_code == 201, upload_response.text
        photo_key = upload_response.json()['photo_keys'][0]
        uploaded_path = Path(photo_key.lstrip('/'))

        categories_response = client.get('/api/v1/categories')
        assert categories_response.status_code == 200
        category_id = categories_response.json()[0]['id']
        ad_response = client.post('/api/v1/ads', headers=headers(seller_token), json={
            'title': 'Молоко фермерское', 'description': 'Свежее', 'price': '120.00', 'unit': 'литр',
            'stock_quantity': '10.000', 'category_id': category_id, 'location_ids': [location_id],
            'photo_keys': [photo_key], 'availability': 'in_stock', 'fulfillment': 'pickup',
        })
        assert ad_response.status_code == 201, ad_response.text
        ad_id = ad_response.json()['id']

        assert client.post('/api/v1/ads/' + str(ad_id) + '/submit', headers=headers(seller_token)).status_code == 200
        rejected_without_reason = client.post(
            '/api/v1/admin/moderation/ads/' + str(ad_id), headers=headers(admin_token), json={'approve': False},
        )
        assert rejected_without_reason.status_code == 422

        moderation_response = client.post(
            '/api/v1/admin/moderation/ads/' + str(ad_id), headers=headers(admin_token), json={'approve': True},
        )
        assert moderation_response.status_code == 200, moderation_response.text
        assert moderation_response.json()['status'] == 'active'

        visible_ads = client.get('/api/v1/ads', headers=headers(buyer_token))
        assert visible_ads.status_code == 200, visible_ads.text
        assert [ad['id'] for ad in visible_ads.json()] == [ad_id]

        favorite_response = client.put('/api/v1/ads/' + str(ad_id) + '/favorite', headers=headers(buyer_token))
        assert favorite_response.status_code == 204
        favorites_response = client.get('/api/v1/favorites', headers=headers(buyer_token))
        assert favorites_response.status_code == 200
        assert [ad['id'] for ad in favorites_response.json()] == [ad_id]

        reservation_response = client.post(
            '/api/v1/ads/' + str(ad_id) + '/reservations', headers=headers(buyer_token), json={'quantity': '2.000'},
        )
        assert reservation_response.status_code == 201, reservation_response.text
        reservation_id = reservation_response.json()['id']
        decision_response = client.post(
            '/api/v1/reservations/' + str(reservation_id) + '/decision',
            headers=headers(seller_token), json={'confirm': True},
        )
        assert decision_response.status_code == 200
        assert decision_response.json()['status'] == 'confirmed'

        conversation_response = client.post('/api/v1/ads/' + str(ad_id) + '/conversation', headers=headers(buyer_token))
        assert conversation_response.status_code == 201
        conversation_id = conversation_response.json()['id']
        message_response = client.post(
            '/api/v1/conversations/' + str(conversation_id) + '/messages',
            headers=headers(buyer_token), json={'body': 'Когда можно забрать?'},
        )
        assert message_response.status_code == 201
        messages_response = client.get('/api/v1/conversations/' + str(conversation_id) + '/messages', headers=headers(seller_token))
        assert messages_response.status_code == 200
        assert messages_response.json()[0]['body'] == 'Когда можно забрать?'

    Base.metadata.drop_all(bind=engine)
    uploaded_path.unlink(missing_ok=True)
    engine.dispose()
    Path('test_ferma.db').unlink(missing_ok=True)
def test_max_webhook_gateway_and_bot_queue(monkeypatch: pytest.MonkeyPatch) -> None:
    Path('test_ferma.db').unlink(missing_ok=True)
    Base.metadata.drop_all(bind=engine)
    test_settings = replace(
        main_module.settings,
        max_enabled=True,
        max_bot_token='test-max-token',
        max_webhook_secret='test_webhook_secret_123',
        max_webhook_url='https://bot.example.test/integrations/max/webhook',
    )
    with TestClient(app) as client:
        # The app was started while MAX was disabled, so this test can inspect its durable queue without a network worker.
        monkeypatch.setattr(main_module, 'settings', test_settings)
        monkeypatch.setattr(max_bot_module, 'settings', test_settings)
        started_update = {
            'update_type': 'bot_started',
            'timestamp': 1,
            'chat_id': 10,
            'user': {'user_id': 123, 'first_name': 'Test', 'is_bot': False},
        }
        headers = {'X-Max-Bot-Api-Secret': test_settings.max_webhook_secret}
        assert client.post('/integrations/max/webhook', headers=headers, json=started_update).status_code == 200
        assert client.post('/integrations/max/webhook', headers=headers, json=started_update).status_code == 200
        assert client.post('/integrations/max/webhook', json=started_update).status_code == 403
        with SessionLocal() as session:
            assert session.query(MaxInboundUpdate).count() == 1
        assert process_max_inbound_updates() == []
        with SessionLocal() as session:
            user = session.query(User).filter_by(external_id='max:123').one()
            outbound = session.query(MaxOutboundMessage).filter_by(recipient_id=user.id).one()
            assert outbound.buttons[0][0]['type'] == 'request_contact'
        vcf_info = 'BEGIN:VCARD\r\nVERSION:3.0\r\nTEL;TYPE=cell:+79990000000\r\nEND:VCARD\r\n'
        contact_update = {
            'update_type': 'message_created',
            'timestamp': 2,
            'message': {
                'sender': {'user_id': 123, 'first_name': 'Test', 'is_bot': False},
                'body': {
                    'attachments': [{
                        'type': 'contact',
                        'payload': {
                            'vcf_info': vcf_info,
                            'hash': hmac.digest(test_settings.max_bot_token.encode(), vcf_info.encode(), 'sha256').hex(),
                        },
                    }],
                },
            },
        }
        assert client.post('/integrations/max/webhook', headers=headers, json=contact_update).status_code == 200
        assert process_max_inbound_updates() == []
        with SessionLocal() as session:
            assert session.query(User).filter_by(external_id='max:123').one().phone_verified is True
        callback_update = {
            'update_type': 'message_callback',
            'timestamp': 2,
            'callback': {
                'callback_id': 'callback-1',
                'payload': 'menu:profile',
                'user': {'user_id': 123, 'first_name': 'Test', 'is_bot': False},
            },
        }
        assert client.post('/integrations/max/webhook', headers=headers, json=callback_update).status_code == 200
        assert process_max_inbound_updates() == [('callback-1', 'max:123')]
    requests: list[httpx.Request] = []
    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        assert request.headers['Authorization'] == 'test-max-token'
        return httpx.Response(200, json={'success': True})
    gateway = MaxMessenger('test-max-token', 'https://max.example.test', transport=httpx.MockTransport(handler))
    dialog_ids: list[str | None] = []
    gateway._rate_limiter.wait_turn = dialog_ids.append
    gateway.deliver('max:123', 'hello', buttons=[[{'type': 'callback', 'text': 'Go', 'payload': 'menu:home'}]])
    gateway.acknowledge_callback('callback-1', 'max:123')
    gateway.subscribe('https://bot.example.test/integrations/max/webhook', 'test_webhook_secret_123', ['bot_started'])
    assert [(request.url.path, dict(request.url.params)) for request in requests] == [
        ('/messages', {'user_id': '123'}),
        ('/answers', {'callback_id': 'callback-1'}),
        ('/subscriptions', {}),
    ]
    assert dialog_ids == ['123', '123', None]
    failing_gateway = MaxMessenger(
        'test-max-token',
        'https://max.example.test',
        transport=httpx.MockTransport(lambda request: httpx.Response(200, json={'success': False, 'message': 'rejected'})),
    )
    with pytest.raises(MaxApiError, match='rejected'):
        failing_gateway.deliver('max:123', 'hello')
    Base.metadata.drop_all(bind=engine)
    engine.dispose()
    Path('test_ferma.db').unlink(missing_ok=True)

def test_max_dialog_rate_limiter_throttles_callback_responses(monkeypatch: pytest.MonkeyPatch) -> None:
    clock = [10.0]
    delays: list[float] = []

    def sleep(delay: float) -> None:
        delays.append(delay)
        clock[0] += delay

    monkeypatch.setattr(messenger_module.time, 'monotonic', lambda: clock[0])
    monkeypatch.setattr(messenger_module.time, 'sleep', sleep)
    limiter = messenger_module._MaxRateLimiter()
    limiter.wait_turn('123')
    limiter.wait_turn('123')
    assert delays == [pytest.approx(0.5)]


def test_max_outbox_claims_retries_and_notification_delivery(monkeypatch: pytest.MonkeyPatch) -> None:
    Path('test_ferma.db').unlink(missing_ok=True)
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    test_settings = replace(
        main_module.settings,
        max_retry_max_attempts=2,
        max_retry_base_seconds=1,
        max_retry_max_seconds=5,
        max_claim_seconds=60,
    )
    monkeypatch.setattr(main_module, 'settings', test_settings)
    with SessionLocal() as session:
        user = User(
            external_id='max:456', phone_ciphertext='not-used-in-this-test', name='Test user', roles=1,
        )
        session.add(user)
        session.flush()
        event = NotificationEvent(recipient_id=user.id, event_type='broadcast', payload={'body': 'test'})
        session.add(event)
        session.commit()
        event_id = event.id

    claims = claim_max_messages()
    assert len(claims) == 1
    message_id, claim_token = claims[0]
    assert claim_max_messages() == []
    assert max_message_data(message_id, claim_token) is not None
    mark_max_message_delivered(message_id, claim_token, True)
    with SessionLocal() as session:
        event = session.get(NotificationEvent, event_id)
        outbound = session.get(MaxOutboundMessage, message_id)
        assert event and event.delivered_at is not None
        assert outbound and outbound.delivered_at is not None

        failed = MaxOutboundMessage(recipient_id=outbound.recipient_id, text='retry me', buttons=[], attachments=[])
        session.add(failed)
        session.commit()
        failed_id = failed.id

    failed_claim = claim_max_messages()
    assert len(failed_claim) == 1
    mark_max_message_delivered(failed_id, failed_claim[0][1], False, 'temporary MAX error')
    with SessionLocal() as session:
        failed = session.get(MaxOutboundMessage, failed_id)
        assert failed and failed.attempts == 1 and failed.failed_at is None
        assert failed.next_attempt_at and failed.next_attempt_at > utcnow()
    assert claim_max_messages() == []

    with SessionLocal() as session:
        failed = session.get(MaxOutboundMessage, failed_id)
        assert failed is not None
        failed.next_attempt_at = utcnow()
        session.commit()
    terminal_claim = claim_max_messages()
    assert len(terminal_claim) == 1
    mark_max_message_delivered(failed_id, terminal_claim[0][1], False, 'permanent MAX error')
    with SessionLocal() as session:
        failed = session.get(MaxOutboundMessage, failed_id)
        assert failed and failed.failed_at is not None and failed.next_attempt_at is None

    Base.metadata.drop_all(bind=engine)
    engine.dispose()
    Path('test_ferma.db').unlink(missing_ok=True)
